// ===== NAVIGATION PAR ONGLETS =====
document.querySelectorAll('[data-section]').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const target = this.dataset.section;

        // Masquer toutes les sections
        document.querySelectorAll('.gami-section').forEach(s => s.style.display = 'none');

        // Afficher la section cible
        const section = document.getElementById(target + 'Section');
        if (section) section.style.display = 'block';

        // Mettre à jour les onglets actifs
        document.querySelectorAll('[data-section]').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
    });
});

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && document.querySelector(href)) {
            e.preventDefault();
            document.querySelector(href).scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// ===== BARRE DE PROGRESSION ANIMÉE =====
document.querySelectorAll('.progress-fill[data-width]').forEach(bar => {
    const width = bar.getAttribute('data-width');
    setTimeout(() => { bar.style.width = width + '%'; }, 200);
});

// ===== CONFIRMATION SUPPRESSION =====
document.querySelectorAll('.btn-delete-confirm').forEach(btn => {
    btn.addEventListener('click', function (e) {
        if (!confirm('Confirmer la suppression ?')) {
            e.preventDefault();
        }
    });
});
