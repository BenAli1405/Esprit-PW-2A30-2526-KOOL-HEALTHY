<?php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../MODEL/Badge.php';

class BadgeController
{
    public function listeBadges(): array
    {
        $db = config::getConnexion();
        return $db->query("SELECT * FROM badges ORDER BY points_requis ASC")->fetchAll();
    }

    public function ajouterBadge(Badge $badge): int
    {
        $db = config::getConnexion();
        $sql = "INSERT INTO badges (nom, icone, points_requis) VALUES (:nom, :icone, :points_requis)";
        $req = $db->prepare($sql);
        $req->execute([
            'nom'           => $badge->getNom(),
            'icone'         => $badge->getIcone(),
            'points_requis' => $badge->getPointsRequis(),
        ]);
        return (int) $db->lastInsertId();
    }

    public function supprimerBadge(int $id): bool
    {
        $db = config::getConnexion();
        $req = $db->prepare("DELETE FROM badges WHERE id = :id");
        return $req->execute(['id' => $id]);
    }

    public function totalBadgesDebloques(): int
    {
        $db = config::getConnexion();
        return (int) $db->query("SELECT COUNT(*) FROM utilisateurs_badges")->fetchColumn();
    }

    public function listeBadgesUtilisateur(int $utilisateurId): array
    {
        $db = config::getConnexion();
        $sql = "SELECT b.* FROM badges b
                INNER JOIN utilisateurs_badges ub ON ub.badge_id = b.id
                WHERE ub.utilisateur_id = :uid
                ORDER BY b.points_requis ASC";
        $req = $db->prepare($sql);
        $req->execute(['uid' => $utilisateurId]);
        return $req->fetchAll();
    }
}

// ---- Routage direct ----
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    $controller = new BadgeController();
    $action     = $_GET['action'] ?? '';

    if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $nom = trim($_POST['nom'] ?? '');
        if (!$nom) {
            header('Location: ../VIEW/backoffice-gamification.php?tab=badges&error=nom');
            exit();
        }
        $badge = new Badge(
            $nom,
            trim($_POST['icone'] ?? 'fa-medal'),
            (int) ($_POST['points_requis'] ?? 0)
        );
        $controller->ajouterBadge($badge);
        header('Location: ../VIEW/backoffice-gamification.php?tab=badges&success=added');
        exit();
    }

    if ($action === 'delete' && isset($_GET['id'])) {
        $controller->supprimerBadge((int) $_GET['id']);
        header('Location: ../VIEW/backoffice-gamification.php?tab=badges&success=deleted');
        exit();
    }

    header('Location: ../VIEW/backoffice-gamification.php');
    exit();
}
?>
