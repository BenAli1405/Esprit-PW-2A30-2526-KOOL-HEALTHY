<?php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../MODEL/Participation.php';

class ParticipationController
{
    public function listeParticipations(): array
    {
        $db = config::getConnexion();
        $sql = "SELECT p.*, u.nom AS utilisateur_nom, d.titre AS defi_titre, d.points AS defi_points
                FROM participations p
                LEFT JOIN utilisateurs u ON u.id = p.utilisateur_id
                LEFT JOIN defis d ON d.id = p.defi_id
                ORDER BY p.created_at DESC";
        return $db->query($sql)->fetchAll();
    }

    public function participer(int $utilisateur_id, int $defi_id): bool
    {
        $db = config::getConnexion();
        try {
            $req = $db->prepare(
                "INSERT IGNORE INTO participations (utilisateur_id, defi_id, progression, termine, points_gagnes)
                 VALUES (:uid, :did, 0, 0, 0)"
            );
            return $req->execute(['uid' => $utilisateur_id, 'did' => $defi_id]);
        } catch (Exception $e) {
            return false;
        }
    }

    public function classement(): array
    {
        $db = config::getConnexion();
        $sql = "SELECT u.id, u.nom,
                       COALESCE(SUM(p.points_gagnes),0) AS total_points,
                       COUNT(DISTINCT ub.badge_id) AS total_badges,
                       COALESCE(SUM(p.termine),0) AS defis_completes
                FROM utilisateurs u
                LEFT JOIN participations p ON p.utilisateur_id = u.id
                LEFT JOIN utilisateurs_badges ub ON ub.utilisateur_id = u.id
                GROUP BY u.id, u.nom
                ORDER BY total_points DESC
                LIMIT 10";
        $rows = $db->query($sql)->fetchAll();
        foreach ($rows as $i => &$row) {
            $row['rang'] = $i + 1;
        }
        return $rows;
    }
}

// ---- Routage direct ----
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    require_once __DIR__ . '/../CONTROLLER/AuthController.php';
    $authController = new AuthController();
    $utilisateur    = $authController->utilisateurConnecte();
    $action         = $_GET['action'] ?? '';

    if ($action === 'participer' && $_SERVER['REQUEST_METHOD'] === 'POST' && $utilisateur) {
        $controller = new ParticipationController();
        $defi_id    = (int) ($_POST['defi_id'] ?? 0);
        $controller->participer((int) $utilisateur['id'], $defi_id);
        header('Location: ../VIEW/gamification.php?success=participating');
        exit();
    }

    header('Location: ../VIEW/gamification.php');
    exit();
}
?>
