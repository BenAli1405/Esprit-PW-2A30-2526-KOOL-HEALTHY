<?php

class Badge
{
    private $id;
    private $nom;
    private $icone;
    private $points_requis;
    private $created_at;

    public function __construct($nom, $icone, $points_requis)
    {
        $this->nom           = $nom;
        $this->icone         = $icone;
        $this->points_requis = $points_requis;
        $this->created_at    = date('Y-m-d H:i:s');
    }

    // Getters
    public function getId()           { return $this->id; }
    public function getNom()          { return $this->nom; }
    public function getIcone()        { return $this->icone; }
    public function getPointsRequis() { return $this->points_requis; }
    public function getCreatedAt()    { return $this->created_at; }

    // Setters
    public function setNom($nom)                { $this->nom           = $nom; }
    public function setIcone($icone)            { $this->icone         = $icone; }
    public function setPointsRequis($pts)       { $this->points_requis = $pts; }
}
?>
