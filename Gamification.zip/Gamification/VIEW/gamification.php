<?php
session_start();
require_once __DIR__ . '/../CONTROLLER/AuthController.php';
require_once __DIR__ . '/../CONTROLLER/DefiController.php';
require_once __DIR__ . '/../CONTROLLER/BadgeController.php';
require_once __DIR__ . '/../CONTROLLER/ParticipationController.php';

$authController        = new AuthController();
$defiController        = new DefiController();
$badgeController       = new BadgeController();
$participationController = new ParticipationController();

$utilisateur = $authController->utilisateurConnecte();
$defis       = $defiController->listeDefis();
$badges      = $badgeController->listeBadges();
$classement  = $participationController->classement();

$success = $_GET['success'] ?? '';
$section = $_GET['section'] ?? 'accueil';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Défis & Récompenses - Kool Healthy</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../CSS/gamification.css">
</head>
<body>

    <!-- TOPBAR -->
    <header class="topbar">
        <a class="brand" href="home.php" aria-label="Kool Healthy">
            <img class="brand-logo" src="../assets/logo-kool-healthy.png" alt="Kool Healthy"
                 onerror="this.onerror=null;this.src='../assets/logo-kh.svg';">
        </a>

        <nav class="top-nav" aria-label="Navigation principale">
            <a href="home.php">Accueil</a>
            <a href="fil-recettes.php">Recettes</a>
            <a href="gamification.php" class="active">🏆 Défis</a>
            <a href="profil.php">Profil</a>
        </nav>

        <div class="topbar-tools">
            <?php if ($utilisateur): ?>
                <span style="font-weight:600; color:var(--vert-kool);">
                    <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($utilisateur['nom']); ?>
                </span>
                <a class="auth-link" href="../CONTROLLER/AuthController.php?action=logout">Déconnexion</a>
            <?php else: ?>
                <a class="auth-link" href="auth.php">Connexion</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- HERO -->
    <div class="hero">
        <h1>Relevez des défis,<br>gagnez des points,<br><span>devenez un héros de l'alimentation durable 🌱</span></h1>
        <p>La gamification au service de votre santé et de la planète</p>
    </div>

    <!-- NAVIGATION ONGLETS -->
    <div class="section-wrap" style="padding-bottom:0;">
        <div class="nav-tabs">
            <a class="nav-tab <?php echo $section==='accueil' ? 'active' : ''; ?>"
               data-section="accueil" href="?section=accueil">
               <i class="fas fa-home"></i> Accueil
            </a>
            <a class="nav-tab <?php echo $section==='defis' ? 'active' : ''; ?>"
               data-section="defis" href="?section=defis">
               <i class="fas fa-trophy"></i> Défis
            </a>
            <a class="nav-tab <?php echo $section==='classement' ? 'active' : ''; ?>"
               data-section="classement" href="?section=classement">
               <i class="fas fa-ranking-star"></i> Classement
            </a>
            <a class="nav-tab <?php echo $section==='badges' ? 'active' : ''; ?>"
               data-section="badges" href="?section=badges">
               <i class="fas fa-medal"></i> Badges
            </a>
        </div>
    </div>

    <?php if ($success): ?>
    <div class="section-wrap" style="padding-top:1rem; padding-bottom:0;">
        <div class="alert success">
            <i class="fas fa-check-circle"></i>
            <?php
            $msgs = [
                'participating' => 'Vous avez rejoint ce défi ! Bonne chance 🎉',
            ];
            echo $msgs[$success] ?? 'Opération réussie.';
            ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- SECTION ACCUEIL -->
    <div id="accueilSection" class="gami-section section-wrap"
         style="<?php echo $section !== 'accueil' ? 'display:none;' : ''; ?>">

        <!-- Tableau de bord utilisateur -->
        <h2 class="section-title"><i class="fas fa-chart-line"></i> Votre tableau de bord</h2>
        <div class="panel stats-user">
            <div class="stat-user-item">
                <div class="stat-user-value">
                    <?php
                    $pts = 0;
                    if ($utilisateur) {
                        $cl = array_filter($classement, fn($c) => $c['id'] === $utilisateur['id']);
                        $pts = $cl ? array_values($cl)[0]['total_points'] : 0;
                    }
                    echo $pts;
                    ?>
                </div>
                <p>Points totaux</p>
            </div>
            <div class="stat-user-item">
                <div class="stat-user-value">
                    <?php
                    $nbBadges = 0;
                    if ($utilisateur) {
                        $cl = array_filter($classement, fn($c) => $c['id'] === $utilisateur['id']);
                        $nbBadges = $cl ? array_values($cl)[0]['total_badges'] : 0;
                    }
                    echo $nbBadges;
                    ?>
                </div>
                <p>Badges débloqués</p>
            </div>
            <div class="stat-user-item">
                <div class="stat-user-value">
                    <?php
                    $nbDefis = 0;
                    if ($utilisateur) {
                        $cl = array_filter($classement, fn($c) => $c['id'] === $utilisateur['id']);
                        $nbDefis = $cl ? array_values($cl)[0]['defis_completes'] : 0;
                    }
                    echo $nbDefis;
                    ?>
                </div>
                <p>Défis complétés</p>
            </div>
        </div>

        <!-- Défis populaires -->
        <h2 class="section-title" style="margin-top:2rem;"><i class="fas fa-fire"></i> Défis populaires</h2>
        <div class="defis-grid">
            <?php foreach (array_slice($defis, 0, 2) as $defi): ?>
            <div class="defi-card">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
                    <h3 style="font-size:1rem;"><?php echo htmlspecialchars($defi['titre']); ?></h3>
                    <span class="defi-points"><?php echo (int)$defi['points']; ?> pts</span>
                </div>
                <p style="margin:8px 0;">
                    <span class="badge-tech"><i class="fas fa-tag"></i> <?php echo htmlspecialchars($defi['type']); ?></span>
                </p>
                <?php if ($defi['date_fin']): ?>
                <p style="font-size:0.8rem; color:var(--muted);">
                    <i class="fas fa-calendar-alt"></i> Jusqu'au <?php echo htmlspecialchars($defi['date_fin']); ?>
                </p>
                <?php endif; ?>
                <?php if ($utilisateur): ?>
                <form method="POST" action="../CONTROLLER/ParticipationController.php?action=participer">
                    <input type="hidden" name="defi_id" value="<?php echo (int)$defi['id']; ?>">
                    <button class="btn-participate" type="submit">
                        <i class="fas fa-play-circle"></i> Participer
                    </button>
                </form>
                <?php else: ?>
                <a href="auth.php" class="btn-participate" style="text-align:center; text-decoration:none; display:block;">
                    Connexion pour participer
                </a>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- SECTION DÉFIS -->
    <div id="defisSection" class="gami-section section-wrap"
         style="<?php echo $section !== 'defis' ? 'display:none;' : ''; ?>">
        <h2 class="section-title"><i class="fas fa-trophy"></i> Tous les défis</h2>
        <div class="defis-grid">
            <?php if (empty($defis)): ?>
                <p style="color:var(--muted);">Aucun défi disponible pour le moment.</p>
            <?php else: ?>
                <?php foreach ($defis as $defi): ?>
                <div class="defi-card">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
                        <h3 style="font-size:1rem;"><?php echo htmlspecialchars($defi['titre']); ?></h3>
                        <span class="defi-points"><?php echo (int)$defi['points']; ?> pts</span>
                    </div>
                    <p style="margin:8px 0;">
                        <span class="badge-tech"><i class="fas fa-tag"></i> <?php echo htmlspecialchars($defi['type']); ?></span>
                    </p>
                    <?php if ($defi['date_debut'] || $defi['date_fin']): ?>
                    <p style="font-size:0.8rem; color:var(--muted);">
                        <i class="fas fa-calendar"></i>
                        <?php echo $defi['date_debut'] ?? ''; ?>
                        <?php if ($defi['date_debut'] && $defi['date_fin']): ?> → <?php endif; ?>
                        <?php echo $defi['date_fin'] ?? ''; ?>
                    </p>
                    <?php endif; ?>
                    <?php if ($utilisateur): ?>
                    <form method="POST" action="../CONTROLLER/ParticipationController.php?action=participer">
                        <input type="hidden" name="defi_id" value="<?php echo (int)$defi['id']; ?>">
                        <button class="btn-participate" type="submit">
                            <i class="fas fa-play-circle"></i> Participer
                        </button>
                    </form>
                    <?php else: ?>
                    <a href="auth.php" class="btn-participate" style="text-align:center; text-decoration:none; display:block;">
                        Connexion pour participer
                    </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- SECTION CLASSEMENT -->
    <div id="classementSection" class="gami-section section-wrap"
         style="<?php echo $section !== 'classement' ? 'display:none;' : ''; ?>">
        <h2 class="section-title"><i class="fas fa-ranking-star"></i> Classement général</h2>
        <div class="ranking-list">
            <?php if (empty($classement)): ?>
                <p style="color:var(--muted);">Aucun participant pour le moment.</p>
            <?php else: ?>
                <?php foreach ($classement as $row): ?>
                <div class="ranking-card">
                    <div class="rank-num">#<?php echo (int)$row['rang']; ?></div>
                    <div>
                        <strong><?php echo htmlspecialchars($row['nom']); ?></strong>
                        <div style="font-size:0.8rem; color:var(--muted);">
                            <?php echo (int)$row['total_points']; ?> pts ·
                            <?php echo (int)$row['total_badges']; ?> badges ·
                            <?php echo (int)$row['defis_completes']; ?> défis
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- SECTION BADGES -->
    <div id="badgesSection" class="gami-section section-wrap"
         style="<?php echo $section !== 'badges' ? 'display:none;' : ''; ?>">
        <h2 class="section-title"><i class="fas fa-medal"></i> Collection de badges</h2>
        <div class="badge-list" style="gap:1.2rem;">
            <?php if (empty($badges)): ?>
                <p style="color:var(--muted);">Aucun badge disponible.</p>
            <?php else: ?>
                <?php foreach ($badges as $badge): ?>
                <div class="badge-item" style="padding:0.8rem 1.4rem; font-size:1rem;">
                    <i class="fas <?php echo htmlspecialchars($badge['icone']); ?>"></i>
                    <?php echo htmlspecialchars($badge['nom']); ?>
                    <span style="font-size:0.75rem; opacity:0.7;">(<?php echo (int)$badge['points_requis']; ?> pts)</span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="footer-content">
            <p>&copy; 2026 Kool Healthy — Manger mieux, gagner des points, préserver la planète 🌱</p>
        </div>
    </footer>

    <script src="../JS/gamification.js"></script>
</body>
</html>
