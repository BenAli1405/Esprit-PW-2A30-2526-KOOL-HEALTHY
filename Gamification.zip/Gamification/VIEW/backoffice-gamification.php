﻿<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Back Office - CRUD Complet avec Modales</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #F5F5F5; color: #1E2A22; }
    :root {
      --vert-kool: #4CAF50;
      --vert-kool-dark: #2E7D32;
      --vert-kool-light: #E8F5E9;
      --bleu-tech: #29B6F6;
      --bleu-tech-dark: #0288D1;
      --bleu-tech-light: #E1F5FE;
      --blanc: #FFFFFF;
      --gris-clair: #F5F5F5;
      --gris-moyen: #E9ECEF;
      --gris-texte: #5F6B66;
      --ombre-legere: 0 12px 28px rgba(0, 0, 0, 0.05);
    }
    .app-wrapper { display: flex; min-height: 100vh; }
    .sidebar {
      width: 280px;
      background: var(--blanc);
      border-right: 1px solid var(--gris-moyen);
      display: flex;
      flex-direction: column;
      position: sticky;
      top: 0;
      height: 100vh;
      overflow-y: auto;
    }
    .logo-area { padding: 32px 24px; border-bottom: 1px solid var(--gris-moyen); margin-bottom: 24px; }
    .logo-area h2 { font-weight: 800; font-size: 1.7rem; display: flex; align-items: center; gap: 10px; color: var(--vert-kool); }
    .logo-area h2 i { color: var(--bleu-tech); font-size: 2rem; }
    .logo-area p { font-size: 0.7rem; color: var(--gris-texte); margin-top: 8px; }
    .nav-menu { flex: 1; padding: 0 16px; }
    .nav-item {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 12px 18px;
      margin: 6px 0;
      border-radius: 16px;
      font-weight: 500;
      transition: all 0.2s;
      color: #4A5B4E;
      cursor: pointer;
    }
    .nav-item i { width: 24px; font-size: 1.2rem; color: var(--bleu-tech); }
    .nav-item.active { background: var(--vert-kool-light); color: var(--vert-kool-dark); }
    .nav-item.active i { color: var(--vert-kool); }
    .nav-item:hover:not(.active) { background: var(--gris-clair); }
    .sidebar-footer { padding: 20px 20px 30px; border-top: 1px solid var(--gris-moyen); margin-top: 20px; }
    .user-badge { display: flex; align-items: center; gap: 12px; }
    .user-avatar { width: 44px; height: 44px; background: linear-gradient(135deg, var(--vert-kool), var(--bleu-tech)); border-radius: 32px; display: flex; align-items: center; justify-content: center; color: white; }
    .main-content { flex: 1; background: #F8F9FA; overflow-x: auto; }
    .top-bar {
      background: var(--blanc);
      padding: 20px 32px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      border-bottom: 1px solid var(--gris-moyen);
    }
    .page-title h1 { font-size: 1.8rem; font-weight: 700; background: linear-gradient(135deg, var(--vert-kool), var(--bleu-tech)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    .page-title p { color: var(--gris-texte); font-size: 0.85rem; margin-top: 6px; }
    .btn-primary {
      background: var(--vert-kool);
      border: none;
      padding: 10px 22px;
      border-radius: 40px;
      font-weight: 600;
      color: white;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      transition: 0.2s;
      font-size: 0.85rem;
    }
    .btn-primary:hover { background: var(--vert-kool-dark); transform: translateY(-1px); }
    .btn-outline {
      background: transparent;
      border: 1px solid var(--bleu-tech);
      color: var(--bleu-tech-dark);
      padding: 8px 18px;
      border-radius: 40px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: 0.2s;
    }
    .btn-outline:hover { background: var(--bleu-tech-light); }
    .btn-danger {
      background: #ef5350;
      border: none;
      padding: 6px 14px;
      border-radius: 40px;
      font-weight: 600;
      color: white;
      cursor: pointer;
      font-size: 0.7rem;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .btn-edit {
      background: var(--bleu-tech);
      border: none;
      padding: 6px 14px;
      border-radius: 40px;
      font-weight: 600;
      color: white;
      cursor: pointer;
      font-size: 0.7rem;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-right: 8px;
    }
    .btn-show-more {
      background: transparent;
      border: 1px solid var(--vert-kool);
      color: var(--vert-kool-dark);
      padding: 8px 20px;
      border-radius: 40px;
      font-weight: 500;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: 0.2s;
      margin-top: 16px;
      font-size: 0.8rem;
    }
    .btn-show-more:hover { background: var(--vert-kool-light); border-color: var(--vert-kool); }
    .unified-container { padding: 28px 32px; max-width: 1600px; margin: 0 auto; }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 24px;
      margin-bottom: 32px;
    }
    .stat-card {
      background: var(--blanc);
      border-radius: 28px;
      padding: 22px 24px;
      box-shadow: var(--ombre-legere);
      border: 1px solid rgba(0,0,0,0.02);
    }
    .stat-title { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: var(--gris-texte); margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
    .stat-value { font-size: 2.4rem; font-weight: 800; color: var(--vert-kool); }
    .section-card {
      background: var(--blanc);
      border-radius: 28px;
      padding: 24px 28px;
      box-shadow: var(--ombre-legere);
      margin-bottom: 32px;
      border: 1px solid var(--gris-moyen);
    }
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 24px;
      border-bottom: 2px solid var(--gris-moyen);
      padding-bottom: 16px;
    }
    .section-header h2 { font-size: 1.5rem; font-weight: 700; display: flex; align-items: center; gap: 12px; color: #2C3E2F; }
    .badge-tech { background: var(--bleu-tech-light); color: var(--bleu-tech-dark); padding: 4px 14px; border-radius: 40px; font-size: 0.7rem; font-weight: 600; display: inline-flex; align-items: center; gap: 5px; }
    .badge-eco { background: var(--vert-kool-light); color: var(--vert-kool-dark); padding: 4px 14px; border-radius: 40px; font-size: 0.7rem; font-weight: 600; }
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table th { text-align: left; padding: 14px 8px 12px 0; font-weight: 600; font-size: 0.75rem; color: #6C7A73; border-bottom: 1px solid var(--gris-moyen); }
    .data-table td { padding: 14px 8px 14px 0; border-bottom: 1px solid #F0F2F0; font-size: 0.85rem; vertical-align: middle; }
    .progress-bar-bg { background: var(--gris-moyen); border-radius: 20px; height: 8px; overflow: hidden; width: 120px; }
    .progress-fill { background: var(--vert-kool); height: 100%; border-radius: 20px; }
    .flex-progress { display: flex; align-items: center; gap: 12px; }
    .rank-badge { background: linear-gradient(135deg, #FFC107, #FF8F00); color: white; padding: 4px 14px; border-radius: 40px; font-size: 0.75rem; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; }
    .status-active { background: var(--vert-kool-light); color: var(--vert-kool-dark); padding: 4px 12px; border-radius: 40px; font-size: 0.7rem; font-weight: 600; }
    .badges-grid { display: flex; flex-wrap: wrap; gap: 24px; margin-top: 16px; }
    .badge-card {
      background: #FFFFFF;
      border-radius: 24px;
      width: 200px;
      text-align: center;
      padding: 20px 16px;
      transition: all 0.2s;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
      border: 1px solid var(--gris-moyen);
    }
    .badge-card i { font-size: 2.8rem; background: linear-gradient(145deg, var(--vert-kool), var(--bleu-tech)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    .table-footer { text-align: center; margin-top: 16px; }
    
    /* MODALES */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      justify-content: center;
      align-items: center;
      z-index: 2000;
      backdrop-filter: blur(3px);
    }
    .modal-content {
      background: white;
      border-radius: 32px;
      width: 90%;
      max-width: 1100px;
      max-height: 85vh;
      display: flex;
      flex-direction: column;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
      animation: modalFadeIn 0.2s ease;
    }
    @keyframes modalFadeIn {
      from { opacity: 0; transform: scale(0.95); }
      to { opacity: 1; transform: scale(1); }
    }
    .modal-header {
      padding: 20px 28px;
      border-bottom: 2px solid var(--gris-moyen);
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: var(--blanc);
      border-radius: 32px 32px 0 0;
    }
    .modal-header h3 { font-size: 1.5rem; font-weight: 700; display: flex; align-items: center; gap: 12px; color: var(--vert-kool); }
    .close-modal {
      font-size: 1.8rem;
      cursor: pointer;
      color: var(--gris-texte);
      transition: 0.2s;
      line-height: 1;
    }
    .close-modal:hover { color: #ef5350; transform: scale(1.1); }
    .modal-body {
      padding: 24px 28px;
      overflow-y: auto;
      flex: 1;
    }
    .full-table { width: 100%; border-collapse: collapse; }
    .full-table th { text-align: left; padding: 12px 8px; background: #F8F9FA; position: sticky; top: 0; }
    .full-table td { padding: 12px 8px; border-bottom: 1px solid var(--gris-moyen); }
    .badges-modal-grid { display: flex; flex-wrap: wrap; gap: 20px; justify-content: flex-start; }
    
    @media (max-width: 900px) {
      .sidebar { width: 85px; }
      .sidebar .logo-area h2 span, .sidebar .nav-item span, .sidebar .user-info { display: none; }
      .nav-item { justify-content: center; }
      .unified-container { padding: 20px; }
    }
  </style>
</head>
<body>
<div class="app-wrapper">
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>back office ·</p>
    </div>
    <div class="nav-menu">
      <div class="nav-item active" data-tab="unified"><i class="fas fa-chart-simple"></i><span>Gamification</span></div>
    </div>
    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user-md"></i></div>
        <div class="user-info"><p>Dr. Emma Green</p><small>admin@koolhealthy.com</small></div>
      </div>
    </div>
  </aside>

  <main class="main-content">
    <div class="top-bar">
      <div class="page-title">
        <h1><i class="fas fa-gamepad"></i> Gamification</h1>
        <p>Défis · Classement · Badges · Participations</p>
      </div>
      <div class="header-actions">
        <button class="btn-primary" id="openGlobalDefiBtn"><i class="fas fa-plus-circle"></i> Nouveau défi</button>
        <button class="btn-outline" id="openGlobalBadgeBtn"><i class="fas fa-medal"></i> Ajouter badge</button>
      </div>
    </div>

    <div class="unified-container">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-title"><i class="fas fa-trophy"></i> Défis actifs</div><div class="stat-value" id="statsDefisActifs">0</div></div>
        <div class="stat-card"><div class="stat-title"><i class="fas fa-users"></i> Participants totaux</div><div class="stat-value" id="statsParticipants">0</div></div>
        <div class="stat-card"><div class="stat-title"><i class="fas fa-star"></i> Points distribués</div><div class="stat-value" id="statsPoints">0</div></div>
        <div class="stat-card"><div class="stat-title"><i class="fas fa-medal"></i> Badges créés</div><div class="stat-value" id="statsBadges">0</div></div>
      </div>

      <!-- SECTION DÉFIS -->
      <div class="section-card">
        <div class="section-header">
          <h2><i class="fas fa-tasks" style="color: var(--vert-kool);"></i> Gestion des défis</h2>
          <button class="btn-outline" id="quickAddDefi"><i class="fas fa-plus"></i> Ajouter un défi</button>
        </div>
        <div style="overflow-x: auto;">
          <table class="data-table" style="width:100%">
            <thead><tr><th>ID</th><th>Titre</th><th>Type</th><th>Points</th><th>Date début</th><th>Date fin</th><th>Actions</th></tr></thead>
            <tbody id="defisListUnified"></tbody>
          </table>
        </div>
        <div id="defisFooter" class="table-footer"></div>
      </div>

      <!-- CLASSEMENT + BADGES -->
      <div style="display: flex; flex-wrap: wrap; gap: 32px; margin-bottom: 32px;">
        <div style="flex: 2; min-width: 260px;">
          <div class="section-card" style="height: 100%;">
            <div class="section-header">
              <h2><i class="fas fa-chart-line" style="color: var(--bleu-tech);"></i> Classement général</h2>
              <div class="badge-tech"><i class="fas fa-fire"></i> Top performants</div>
            </div>
            <div style="overflow-x: auto;">
              <table class="data-table" style="width:100%">
                <thead><tr><th>Rang</th><th>Utilisateur</th><th>Points totaux</th><th>Badges</th><th>Défis complétés</th></tr></thead>
                <tbody id="classementListUnified"></tbody>
              </table>
            </div>
            <div id="classementFooter" class="table-footer"></div>
          </div>
        </div>
        <div style="flex: 1.5; min-width: 280px;">
          <div class="section-card" style="height: 100%;">
            <div class="section-header">
              <h2><i class="fas fa-medal" style="color: var(--vert-kool);"></i> Badges & récompenses</h2>
              <button class="btn-outline" id="quickAddBadgeBtn"><i class="fas fa-plus"></i> Badge</button>
            </div>
            <div id="badgesGridUnified" class="badges-grid"></div>
            <div id="badgesFooter" class="table-footer"></div>
          </div>
        </div>
      </div>

      <!-- PARTICIPATIONS -->
      <div class="section-card">
        <div class="section-header">
          <h2><i class="fas fa-clipboard-list"></i> Suivi des participations</h2>
          <div class="badge-tech"><i class="fas fa-chart-simple"></i> progression</div>
        </div>
        <table class="data-table" style="width:100%">
          <thead><tr><th>Utilisateur</th><th>Défi</th><th>Progression</th><th>Statut</th><th>Points gagnés</th></tr></thead>
          <tbody id="participationsListUnified"></tbody>
        </table>
        <div id="participationsFooter" class="table-footer"></div>
      </div>
    </div>
  </main>
</div>

<!-- MODALES POUR AFFICHER TOUT -->
<div id="modalDefis" class="modal"><div class="modal-content"><div class="modal-header"><h3><i class="fas fa-tasks"></i> Tous les défis</h3><span class="close-modal" data-modal="defis">&times;</span></div><div class="modal-body"><table class="full-table" id="modalDefisTable"><thead><tr><th>ID</th><th>Titre</th><th>Type</th><th>Points</th><th>Date début</th><th>Date fin</th><th>Actions</th></tr></thead><tbody></tbody></table></div></div></div>
<div id="modalClassement" class="modal"><div class="modal-content"><div class="modal-header"><h3><i class="fas fa-chart-line"></i> Classement complet</h3><span class="close-modal" data-modal="classement">&times;</span></div><div class="modal-body"><table class="full-table" id="modalClassementTable"><thead><tr><th>Rang</th><th>Utilisateur</th><th>Points totaux</th><th>Badges</th><th>Défis complétés</th></tr></thead><tbody></tbody></table></div></div></div>
<div id="modalBadges" class="modal"><div class="modal-content"><div class="modal-header"><h3><i class="fas fa-medal"></i> Tous les badges</h3><span class="close-modal" data-modal="badges">&times;</span></div><div class="modal-body"><div id="modalBadgesGrid" class="badges-modal-grid"></div></div></div></div>
<div id="modalParticipations" class="modal"><div class="modal-content"><div class="modal-header"><h3><i class="fas fa-users"></i> Toutes les participations</h3><span class="close-modal" data-modal="participations">&times;</span></div><div class="modal-body"><table class="full-table" id="modalParticipationsTable"><thead><tr><th>Utilisateur</th><th>Défi</th><th>Progression</th><th>Statut</th><th>Points</th></tr></thead><tbody></tbody></table></div></div></div>

<!-- MODALES CRUD -->
<div id="addDefiModal" class="modal"><div class="modal-content" style="max-width:500px;"><div class="modal-header"><h3><i class="fas fa-plus-circle"></i> Nouveau défi</h3><span class="close-modal" id="closeDefiModal">&times;</span></div><div class="modal-body"><input type="text" id="defiTitre" placeholder="Titre du défi" style="width:100%; padding:12px; margin-bottom:12px; border-radius:60px; border:1px solid #ddd;"><select id="defiType" style="width:100%; padding:12px; margin-bottom:12px; border-radius:60px;"><option value="nutrition">🍏 Nutrition</option><option value="ecologie">🌿 Écologie</option><option value="recette">🥗 Recette</option><option value="social">🤝 Social</option></select><input type="number" id="defiPoints" placeholder="Points" style="width:100%; padding:12px; margin-bottom:12px; border-radius:60px;"><input type="date" id="defiDateDebut" style="width:100%; padding:12px; margin-bottom:12px;"><input type="date" id="defiDateFin" style="width:100%; padding:12px; margin-bottom:12px;"><button class="btn-primary" id="saveDefiBtn" style="width:100%;">Créer le défi</button></div></div></div>
<div id="editDefiModal" class="modal"><div class="modal-content" style="max-width:500px;"><div class="modal-header"><h3><i class="fas fa-edit"></i> Modifier défi</h3><span class="close-modal" id="closeEditDefiModal">&times;</span></div><div class="modal-body"><input type="hidden" id="editDefiId"><input type="text" id="editDefiTitre" placeholder="Titre" style="width:100%; padding:12px; margin-bottom:12px;"><select id="editDefiType" style="width:100%; padding:12px; margin-bottom:12px;"><option value="nutrition">🍏 Nutrition</option><option value="ecologie">🌿 Écologie</option><option value="recette">🥗 Recette</option><option value="social">🤝 Social</option></select><input type="number" id="editDefiPoints" placeholder="Points" style="width:100%; padding:12px; margin-bottom:12px;"><input type="date" id="editDefiDateDebut" style="width:100%; margin-bottom:12px;"><input type="date" id="editDefiDateFin" style="width:100%; margin-bottom:12px;"><button class="btn-primary" id="updateDefiBtn" style="width:100%;">Mettre à jour</button></div></div></div>
<div id="addBadgeModal" class="modal"><div class="modal-content" style="max-width:500px;"><div class="modal-header"><h3><i class="fas fa-medal"></i> Nouveau badge</h3><span class="close-modal" id="closeBadgeModal">&times;</span></div><div class="modal-body"><input type="text" id="badgeNom" placeholder="Nom du badge" style="width:100%; padding:12px; margin-bottom:12px;"><input type="text" id="badgeIcon" placeholder="Icône (ex: fa-leaf, fa-carrot)" style="width:100%; padding:12px; margin-bottom:12px;"><input type="number" id="badgePointsRequis" placeholder="Points requis" style="width:100%; padding:12px; margin-bottom:12px;"><button class="btn-primary" id="saveBadgeBtn" style="width:100%;">Créer badge</button></div></div></div>

<script>
  // ========== DONNÉES ==========
  let defis = [
    { id: 1, titre: "Manger 5 fruits/légumes par jour", type: "nutrition", points: 50, dateDebut: "2025-03-01", dateFin: "2025-03-31" },
    { id: 2, titre: "Réduire son empreinte carbone", type: "ecologie", points: 100, dateDebut: "2025-03-01", dateFin: "2025-04-15" },
    { id: 3, titre: "Tester 3 recettes végétales", type: "recette", points: 75, dateDebut: "2025-03-10", dateFin: "2025-04-10" },
    { id: 4, titre: "Partager un repas durable", type: "social", points: 30, dateDebut: "2025-03-15", dateFin: "2025-03-30" },
    { id: 5, titre: "Défi zéro déchet", type: "ecologie", points: 120, dateDebut: "2025-04-01", dateFin: "2025-04-30" }
  ];
  let badges = [
    { id: 1, nom: "Éco-citoyen", icone: "fa-leaf", pointsRequis: 100 },
    { id: 2, nom: "Chef végétal", icone: "fa-carrot", pointsRequis: 200 },
    { id: 3, nom: "Ambassadeur", icone: "fa-star", pointsRequis: 500 },
    { id: 4, nom: "Zéro Déchet", icone: "fa-recycle", pointsRequis: 300 }
  ];
  let participations = [
    { utilisateur: "Sophie M.", defi: "Manger 5 fruits/légumes par jour", progression: 80, termine: false, points: 40 },
    { utilisateur: "Julien R.", defi: "Réduire son empreinte carbone", progression: 45, termine: false, points: 45 },
    { utilisateur: "Léa B.", defi: "Tester 3 recettes végétales", progression: 100, termine: true, points: 75 },
    { utilisateur: "Thomas L.", defi: "Partager un repas durable", progression: 60, termine: false, points: 18 },
    { utilisateur: "Emma C.", defi: "Défi zéro déchet", progression: 30, termine: false, points: 36 }
  ];
  let classement = [
    { rang: 1, nom: "Julien R.", points: 1250, badges: 3, defisCompletes: 5 },
    { rang: 2, nom: "Sophie M.", points: 980, badges: 2, defisCompletes: 4 },
    { rang: 3, nom: "Léa B.", points: 750, badges: 2, defisCompletes: 3 },
    { rang: 4, nom: "Thomas L.", points: 620, badges: 1, defisCompletes: 2 },
    { rang: 5, nom: "Emma C.", points: 510, badges: 1, defisCompletes: 2 }
  ];
  let nextDefiId = 6, nextBadgeId = 5;

  const DEFAULT_VISIBLE = 3;

  function escapeHtml(str) { if(!str) return ''; return str.replace(/[&<>]/g, function(m){return m==='&'?'&amp;':m==='<'?'&lt;':'&gt;';}); }

  // RENDER des sections avec seulement 3 lignes
  function renderDefisTable() {
    const tbody = document.getElementById('defisListUnified');
    const visibleDefis = defis.slice(0, DEFAULT_VISIBLE);
    tbody.innerHTML = visibleDefis.map(d => `<tr><td>${d.id}</td><td><strong>${escapeHtml(d.titre)}</strong></td><td><span class="badge-tech">${d.type}</span></td><td><span class="badge-eco">${d.points} pts</span></td><td>${d.dateDebut}</td><td>${d.dateFin}</td><td><button class="btn-edit" onclick="openEditDefiModal(${d.id})"><i class="fas fa-pen"></i> Modifier</button><button class="btn-danger" onclick="deleteDefiHandler(${d.id})"><i class="fas fa-trash"></i></button></td></tr>`).join('');
    const footer = document.getElementById('defisFooter');
    if (defis.length > DEFAULT_VISIBLE) footer.innerHTML = `<button class="btn-show-more" onclick="openModal('defis')"><i class="fas fa-eye"></i> Afficher tout (${defis.length} défis)</button>`;
    else footer.innerHTML = '';
  }
  function renderClassementTable() {
    const tbody = document.getElementById('classementListUnified');
    const visible = classement.slice(0, DEFAULT_VISIBLE);
    tbody.innerHTML = visible.map(c => `<tr><td><span class="rank-badge">#${c.rang}</span></td><td><strong>${escapeHtml(c.nom)}</strong></td><td>${c.points} pts</td><td>🏅 ${c.badges}</td><td>✔ ${c.defisCompletes}</td></tr>`).join('');
    const footer = document.getElementById('classementFooter');
    if (classement.length > DEFAULT_VISIBLE) footer.innerHTML = `<button class="btn-show-more" onclick="openModal('classement')"><i class="fas fa-eye"></i> Afficher tout (${classement.length} participants)</button>`;
    else footer.innerHTML = '';
  }
  function renderBadgesGrid() {
    const container = document.getElementById('badgesGridUnified');
    const visible = badges.slice(0, DEFAULT_VISIBLE);
    container.innerHTML = visible.map(b => `<div class="badge-card"><i class="fas ${b.icone}"></i><h4>${escapeHtml(b.nom)}</h4><p><i class="fas fa-star"></i> ${b.pointsRequis} pts</p><button class="btn-danger" onclick="deleteBadgeHandler(${b.id})">Supprimer</button></div>`).join('');
    const footer = document.getElementById('badgesFooter');
    if (badges.length > DEFAULT_VISIBLE) footer.innerHTML = `<button class="btn-show-more" onclick="openModal('badges')"><i class="fas fa-eye"></i> Afficher tout (${badges.length} badges)</button>`;
    else footer.innerHTML = '';
  }
  function renderParticipationsTable() {
    const tbody = document.getElementById('participationsListUnified');
    const visible = participations.slice(0, DEFAULT_VISIBLE);
    tbody.innerHTML = visible.map(p => `<tr><td><i class="fas fa-user-circle"></i> ${escapeHtml(p.utilisateur)}</td><td>${escapeHtml(p.defi)}</td><td><div class="flex-progress"><div class="progress-bar-bg"><div class="progress-fill" style="width:${p.progression}%"></div></div>${p.progression}%</div></td><td>${p.termine ? '<span class="status-active">Terminé</span>' : '<span class="badge-tech">En cours</span>'}</td><td>${p.points} pts</td></tr>`).join('');
    const footer = document.getElementById('participationsFooter');
    if (participations.length > DEFAULT_VISIBLE) footer.innerHTML = `<button class="btn-show-more" onclick="openModal('participations')"><i class="fas fa-eye"></i> Afficher tout (${participations.length} participations)</button>`;
    else footer.innerHTML = '';
  }

  // OUVERTURE MODALE avec toutes les données
  window.openModal = (type) => {
    if (type === 'defis') {
      const tbody = document.querySelector('#modalDefisTable tbody');
      tbody.innerHTML = defis.map(d => `<tr><td>${d.id}</td><td><strong>${escapeHtml(d.titre)}</strong></td><td>${d.type}</td><td>${d.points}</td><td>${d.dateDebut}</td><td>${d.dateFin}</td><td><button class="btn-edit" onclick="closeAllModals(); openEditDefiModal(${d.id})">Modifier</button><button class="btn-danger" onclick="deleteDefiHandler(${d.id}); closeAllModals();">Supprimer</button></td>`).join('');
      document.getElementById('modalDefis').style.display = 'flex';
    } else if (type === 'classement') {
      const tbody = document.querySelector('#modalClassementTable tbody');
      tbody.innerHTML = classement.map(c => `<tr><td><span class="rank-badge">#${c.rang}</span></td><td><strong>${escapeHtml(c.nom)}</strong></td><td>${c.points} pts</td><td>🏅 ${c.badges}</td><td>✔ ${c.defisCompletes}</td>`).join('');
      document.getElementById('modalClassement').style.display = 'flex';
    } else if (type === 'badges') {
      const container = document.getElementById('modalBadgesGrid');
      container.innerHTML = badges.map(b => `<div class="badge-card"><i class="fas ${b.icone}"></i><h4>${escapeHtml(b.nom)}</h4><p><i class="fas fa-star"></i> ${b.pointsRequis} pts</p><button class="btn-danger" onclick="deleteBadgeHandler(${b.id}); closeAllModals();">Supprimer</button></div>`).join('');
      document.getElementById('modalBadges').style.display = 'flex';
    } else if (type === 'participations') {
      const tbody = document.querySelector('#modalParticipationsTable tbody');
      tbody.innerHTML = participations.map(p => `<tr><td>${escapeHtml(p.utilisateur)}</td><td>${escapeHtml(p.defi)}</td><td><div class="flex-progress"><div class="progress-bar-bg"><div class="progress-fill" style="width:${p.progression}%"></div></div>${p.progression}%</div></td><td>${p.termine ? 'Terminé' : 'En cours'}</td><td>${p.points} pts</td>`).join('');
      document.getElementById('modalParticipations').style.display = 'flex';
    }
  };
  function closeAllModals() {
    document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
  }
  document.querySelectorAll('.close-modal').forEach(btn => { btn.addEventListener('click', () => closeAllModals()); });
  window.onclick = (e) => { if(e.target.classList && e.target.classList.contains('modal')) closeAllModals(); };

  // CRUD COMPLET
  window.deleteDefiHandler = (id) => { if(confirm('Supprimer ce défi ?')) { defis = defis.filter(d => d.id !== id); renderAll(); } };
  window.deleteBadgeHandler = (id) => { if(confirm('Supprimer ce badge ?')) { badges = badges.filter(b => b.id !== id); renderAll(); } };
  window.openEditDefiModal = (id) => {
    const defi = defis.find(d => d.id === id);
    if(defi) {
      document.getElementById('editDefiId').value = defi.id;
      document.getElementById('editDefiTitre').value = defi.titre;
      document.getElementById('editDefiType').value = defi.type;
      document.getElementById('editDefiPoints').value = defi.points;
      document.getElementById('editDefiDateDebut').value = defi.dateDebut;
      document.getElementById('editDefiDateFin').value = defi.dateFin;
      document.getElementById('editDefiModal').style.display = 'flex';
    }
  };
  function renderAll() {
    renderDefisTable(); renderClassementTable(); renderBadgesGrid(); renderParticipationsTable();
    updateStats();
  }
  function updateStats() {
    document.getElementById('statsDefisActifs').innerText = defis.length;
    document.getElementById('statsParticipants').innerText = participations.length;
    const totalPoints = classement.reduce((a,b)=>a+b.points,0);
    document.getElementById('statsPoints').innerText = totalPoints.toLocaleString();
    document.getElementById('statsBadges').innerText = badges.length;
  }
  // Création défi
  document.getElementById('saveDefiBtn').onclick = () => {
    const titre = document.getElementById('defiTitre').value.trim();
    if(!titre) return alert('Titre requis');
    defis.push({ id: nextDefiId++, titre, type: document.getElementById('defiType').value, points: parseInt(document.getElementById('defiPoints').value)||0, dateDebut: document.getElementById('defiDateDebut').value, dateFin: document.getElementById('defiDateFin').value });
    renderAll(); document.getElementById('addDefiModal').style.display = 'none';
    document.getElementById('defiTitre').value = '';
  };
  document.getElementById('updateDefiBtn').onclick = () => {
    const id = parseInt(document.getElementById('editDefiId').value);
    const idx = defis.findIndex(d=>d.id===id);
    if(idx!==-1) { defis[idx] = { ...defis[idx], titre: document.getElementById('editDefiTitre').value, type: document.getElementById('editDefiType').value, points: parseInt(document.getElementById('editDefiPoints').value)||0, dateDebut: document.getElementById('editDefiDateDebut').value, dateFin: document.getElementById('editDefiDateFin').value }; renderAll(); document.getElementById('editDefiModal').style.display = 'none'; }
  };
  document.getElementById('saveBadgeBtn').onclick = () => {
    const nom = document.getElementById('badgeNom').value.trim();
    if(!nom) return alert('Nom requis');
    badges.push({ id: nextBadgeId++, nom, icone: document.getElementById('badgeIcon').value || 'fa-medal', pointsRequis: parseInt(document.getElementById('badgePointsRequis').value)||0 });
    renderAll(); document.getElementById('addBadgeModal').style.display = 'none';
    document.getElementById('badgeNom').value = '';
  };
  // Ouverture modales CRUD
  document.getElementById('openGlobalDefiBtn').onclick = () => document.getElementById('addDefiModal').style.display = 'flex';
  document.getElementById('quickAddDefi').onclick = () => document.getElementById('addDefiModal').style.display = 'flex';
  document.getElementById('openGlobalBadgeBtn').onclick = () => document.getElementById('addBadgeModal').style.display = 'flex';
  document.getElementById('quickAddBadgeBtn').onclick = () => document.getElementById('addBadgeModal').style.display = 'flex';
  document.getElementById('closeDefiModal').onclick = () => document.getElementById('addDefiModal').style.display = 'none';
  document.getElementById('closeEditDefiModal').onclick = () => document.getElementById('editDefiModal').style.display = 'none';
  document.getElementById('closeBadgeModal').onclick = () => document.getElementById('addBadgeModal').style.display = 'none';
  renderAll();
</script>
</body>
</html>
