<?php
session_start();
require_once __DIR__ . '/../CONTROLLER/AuthController.php';
require_once __DIR__ . '/../CONTROLLER/DefiController.php';
require_once __DIR__ . '/../CONTROLLER/BadgeController.php';
require_once __DIR__ . '/../CONTROLLER/ParticipationController.php';

$authController          = new AuthController();
$defiController          = new DefiController();
$badgeController         = new BadgeController();
$participationController = new ParticipationController();

$utilisateur = $authController->utilisateurConnecte();

// Protection admin
if (!$utilisateur || ($utilisateur['role'] ?? '') !== 'admin') {
    header('Location: auth.php');
    exit();
}

$defis          = $defiController->listeDefis();
$badges         = $badgeController->listeBadges();
$participations = $participationController->listeParticipations();
$classement     = $participationController->classement();
$statsDefis     = $defiController->statsDefis();
$totalBadges    = $badgeController->totalBadgesDebloques();

$tab     = $_GET['tab']     ?? 'dashboard';
$success = $_GET['success'] ?? '';
$error   = $_GET['error']   ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kool Healthy | Back Office - Gamification</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <link rel="stylesheet" href="../CSS/gamification.css">
</head>
<body>
<div class="app-wrapper">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="logo-area">
            <h2>
                <i class="fas fa-seedling"></i>
                <span>Kool<br>Healthy</span>
            </h2>
            <p>administration · gamification</p>
        </div>

        <nav class="nav-menu">
            <a class="nav-item <?php echo $tab==='dashboard' ? 'active' : ''; ?>"
               href="?tab=dashboard">
               <i class="fas fa-chart-pie"></i><span>Dashboard</span>
            </a>
            <a class="nav-item <?php echo $tab==='defis' ? 'active' : ''; ?>"
               href="?tab=defis">
               <i class="fas fa-trophy"></i><span>Gestion défis</span>
            </a>
            <a class="nav-item <?php echo $tab==='participations' ? 'active' : ''; ?>"
               href="?tab=participations">
               <i class="fas fa-users"></i><span>Participations</span>
            </a>
            <a class="nav-item <?php echo $tab==='classement' ? 'active' : ''; ?>"
               href="?tab=classement">
               <i class="fas fa-signal"></i><span>Classement</span>
            </a>
            <a class="nav-item <?php echo $tab==='badges' ? 'active' : ''; ?>"
               href="?tab=badges">
               <i class="fas fa-medal"></i><span>Badges</span>
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-badge">
                <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
                <div class="user-info">
                    <p><?php echo htmlspecialchars($utilisateur['nom']); ?></p>
                    <small><?php echo htmlspecialchars($utilisateur['email']); ?></small>
                </div>
            </div>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1><i class="fas fa-gamepad" style="margin-right:8px;"></i> Gamification</h1>
                <p>Gestion des défis, points, badges et classement</p>
            </div>
            <div>
                <a href="gamification.php" class="btn-outline">
                    <i class="fas fa-eye"></i> Voir le front
                </a>
            </div>
        </div>

        <?php if ($success): ?>
        <div style="padding:16px 28px 0;">
            <div class="alert success">
                <i class="fas fa-check-circle"></i>
                <?php
                $msgs = [
                    'added'   => 'Élément ajouté avec succès.',
                    'edited'  => 'Élément modifié avec succès.',
                    'deleted' => 'Élément supprimé.',
                ];
                echo $msgs[$success] ?? 'Opération réussie.';
                ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- ===== DASHBOARD ===== -->
        <?php if ($tab === 'dashboard'): ?>
        <div class="dashboard-container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-title"><i class="fas fa-trophy"></i> Défis actifs</div>
                    <div class="stat-value"><?php echo count($defis); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title"><i class="fas fa-users"></i> Participations</div>
                    <div class="stat-value"><?php echo $statsDefis['participants']; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title"><i class="fas fa-star"></i> Points distribués</div>
                    <div class="stat-value"><?php echo number_format($statsDefis['points_distribues']); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title"><i class="fas fa-medal"></i> Badges débloqués</div>
                    <div class="stat-value"><?php echo $totalBadges; ?></div>
                </div>
            </div>

            <div class="card-panel">
                <div class="panel-header">
                    <h3><i class="fas fa-chart-line" style="color:var(--bleu-tech);"></i> Engagement utilisateur</h3>
                    <div class="badge-tech"><i class="fas fa-robot"></i> suivi IA</div>
                </div>
                <canvas id="engagementChart" height="130"></canvas>
            </div>
        </div>

        <!-- ===== DÉFIS ===== -->
        <?php elseif ($tab === 'defis'): ?>
        <div class="dashboard-container">
            <div class="card-panel">
                <div class="panel-header">
                    <h3><i class="fas fa-list"></i> Liste des défis</h3>
                    <button class="btn-primary" id="openAddDefiModal">
                        <i class="fas fa-plus-circle"></i> Nouveau défi
                    </button>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Titre</th>
                            <th>Type</th>
                            <th>Points</th>
                            <th>Date début</th>
                            <th>Date fin</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($defis)): ?>
                        <tr><td colspan="7" style="text-align:center; color:var(--muted);">Aucun défi pour l'instant.</td></tr>
                        <?php else: ?>
                        <?php foreach ($defis as $defi): ?>
                        <tr>
                            <td><?php echo (int)$defi['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($defi['titre']); ?></strong></td>
                            <td><span class="badge-tech"><i class="fas fa-tag"></i> <?php echo htmlspecialchars($defi['type']); ?></span></td>
                            <td><span class="badge-eco"><i class="fas fa-star"></i> <?php echo (int)$defi['points']; ?> pts</span></td>
                            <td><?php echo htmlspecialchars($defi['date_debut'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($defi['date_fin']   ?? '-'); ?></td>
                            <td>
                                <button class="btn-edit" onclick="openEditDefi(<?php echo (int)$defi['id']; ?>, '<?php echo addslashes($defi['titre']); ?>', '<?php echo $defi['type']; ?>', <?php echo (int)$defi['points']; ?>, '<?php echo $defi['date_debut'] ?? ''; ?>', '<?php echo $defi['date_fin'] ?? ''; ?>')">
                                    <i class="fas fa-pen"></i> Modifier
                                </button>
                                <a class="btn-danger btn-delete-confirm"
                                   href="../CONTROLLER/DefiController.php?action=delete&id=<?php echo (int)$defi['id']; ?>">
                                    <i class="fas fa-trash"></i> Supprimer
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ===== PARTICIPATIONS ===== -->
        <?php elseif ($tab === 'participations'): ?>
        <div class="dashboard-container">
            <div class="card-panel">
                <div class="panel-header">
                    <h3><i class="fas fa-clipboard-list"></i> Suivi des participations</h3>
                    <div class="badge-tech"><i class="fas fa-chart-simple"></i> progression</div>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Utilisateur</th>
                            <th>Défi</th>
                            <th>Progression</th>
                            <th>Statut</th>
                            <th>Points gagnés</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($participations)): ?>
                        <tr><td colspan="5" style="text-align:center; color:var(--muted);">Aucune participation enregistrée.</td></tr>
                        <?php else: ?>
                        <?php foreach ($participations as $p): ?>
                        <tr>
                            <td>
                                <i class="fas fa-user-circle" style="color:var(--bleu-tech);"></i>
                                <?php echo htmlspecialchars($p['utilisateur_nom'] ?? 'Utilisateur'); ?>
                            </td>
                            <td><?php echo htmlspecialchars($p['defi_titre'] ?? '-'); ?></td>
                            <td>
                                <div class="flex-progress">
                                    <div class="progress-bar-bg">
                                        <div class="progress-fill" style="width:<?php echo (int)$p['progression']; ?>%"></div>
                                    </div>
                                    <span><?php echo (int)$p['progression']; ?>%</span>
                                </div>
                            </td>
                            <td>
                                <?php if ($p['termine']): ?>
                                    <span class="status-active"><i class="fas fa-check-circle"></i> Terminé</span>
                                <?php else: ?>
                                    <span class="badge-tech"><i class="fas fa-hourglass-half"></i> En cours</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge-eco">
                                    <i class="fas fa-star"></i> <?php echo (int)$p['points_gagnes']; ?> pts
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ===== CLASSEMENT ===== -->
        <?php elseif ($tab === 'classement'): ?>
        <div class="dashboard-container">
            <div class="card-panel">
                <div class="panel-header">
                    <h3><i class="fas fa-chart-simple"></i> Classement général</h3>
                    <div class="badge-eco"><i class="fas fa-fire"></i> Top 10</div>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Rang</th>
                            <th>Utilisateur</th>
                            <th>Points totaux</th>
                            <th>Badges</th>
                            <th>Défis complétés</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($classement)): ?>
                        <tr><td colspan="5" style="text-align:center; color:var(--muted);">Aucun participant.</td></tr>
                        <?php else: ?>
                        <?php foreach ($classement as $c): ?>
                        <tr>
                            <td><span class="rank-badge"><i class="fas fa-trophy"></i> #<?php echo (int)$c['rang']; ?></span></td>
                            <td><strong><?php echo htmlspecialchars($c['nom']); ?></strong></td>
                            <td><span class="badge-eco"><i class="fas fa-star"></i> <?php echo (int)$c['total_points']; ?> pts</span></td>
                            <td><i class="fas fa-medal" style="color:var(--vert-kool);"></i> <?php echo (int)$c['total_badges']; ?></td>
                            <td><i class="fas fa-flag-checkered" style="color:var(--bleu-tech);"></i> <?php echo (int)$c['defis_completes']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ===== BADGES ===== -->
        <?php elseif ($tab === 'badges'): ?>
        <div class="dashboard-container">
            <div class="card-panel">
                <div class="panel-header">
                    <h3><i class="fas fa-medal"></i> Badges disponibles</h3>
                    <button class="btn-primary" id="openAddBadgeModal">
                        <i class="fas fa-plus"></i> Nouveau badge
                    </button>
                </div>
                <div style="display:flex; flex-wrap:wrap; gap:20px; margin-top:16px;">
                    <?php if (empty($badges)): ?>
                        <p style="color:var(--muted);">Aucun badge configuré.</p>
                    <?php else: ?>
                    <?php foreach ($badges as $badge): ?>
                    <div class="stat-card" style="width:200px; text-align:center;">
                        <i class="fas <?php echo htmlspecialchars($badge['icone']); ?>"
                           style="font-size:2.5rem; color:var(--vert-kool);"></i>
                        <h3 style="margin:10px 0 4px;"><?php echo htmlspecialchars($badge['nom']); ?></h3>
                        <p style="font-size:0.8rem; color:var(--muted);">
                            <i class="fas fa-star" style="color:var(--vert-kool);"></i>
                            <?php echo (int)$badge['points_requis']; ?> pts requis
                        </p>
                        <a class="btn-danger btn-delete-confirm"
                           href="../CONTROLLER/BadgeController.php?action=delete&id=<?php echo (int)$badge['id']; ?>"
                           style="margin-top:10px; display:inline-flex;">
                            <i class="fas fa-trash"></i> Supprimer
                        </a>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- ===== MODAL AJOUT DÉFI ===== -->
<div id="addDefiModal" class="modal">
    <div class="modal-content">
        <span class="close-modal" id="closeDefiModal">&times;</span>
        <h3><i class="fas fa-plus-circle"></i> Nouveau défi</h3>
        <form method="POST" action="../CONTROLLER/DefiController.php?action=add">
            <input type="text" name="titre" placeholder="Titre du défi" required>
            <select name="type">
                <option value="nutrition">🍎 Nutrition</option>
                <option value="ecologie">🌍 Écologie</option>
                <option value="recette">🍳 Recette</option>
                <option value="social">👥 Social</option>
            </select>
            <input type="number" name="points" placeholder="Points" min="0">
            <input type="date" name="date_debut">
            <input type="date" name="date_fin">
            <button class="btn-primary" type="submit" style="width:100%; margin-top:10px;">
                Créer le défi
            </button>
        </form>
    </div>
</div>

<!-- ===== MODAL MODIFICATION DÉFI ===== -->
<div id="editDefiModal" class="modal">
    <div class="modal-content">
        <span class="close-modal" id="closeEditDefiModal">&times;</span>
        <h3><i class="fas fa-edit" style="color:var(--bleu-tech);"></i> Modifier le défi</h3>
        <form method="POST" action="../CONTROLLER/DefiController.php?action=edit">
            <input type="hidden" name="id" id="editDefiId">
            <input type="text" name="titre" id="editDefiTitre" placeholder="Titre du défi" required>
            <select name="type" id="editDefiType">
                <option value="nutrition">🍎 Nutrition</option>
                <option value="ecologie">🌍 Écologie</option>
                <option value="recette">🍳 Recette</option>
                <option value="social">👥 Social</option>
            </select>
            <input type="number" name="points" id="editDefiPoints" placeholder="Points" min="0">
            <input type="date" name="date_debut" id="editDefiDateDebut">
            <input type="date" name="date_fin" id="editDefiDateFin">
            <button class="btn-primary" type="submit" style="width:100%; margin-top:10px;">
                Mettre à jour
            </button>
        </form>
    </div>
</div>

<!-- ===== MODAL AJOUT BADGE ===== -->
<div id="addBadgeModal" class="modal">
    <div class="modal-content">
        <span class="close-modal" id="closeBadgeModal">&times;</span>
        <h3><i class="fas fa-medal"></i> Nouveau badge</h3>
        <form method="POST" action="../CONTROLLER/BadgeController.php?action=add">
            <input type="text" name="nom" placeholder="Nom du badge" required>
            <input type="text" name="icone" placeholder="Icône FontAwesome (ex: fa-leaf, fa-star)">
            <input type="number" name="points_requis" placeholder="Points requis" min="0">
            <button class="btn-primary" type="submit" style="width:100%; margin-top:10px;">
                Créer le badge
            </button>
        </form>
    </div>
</div>

<script>
// Modales
const addDefiModal  = document.getElementById('addDefiModal');
const editDefiModal = document.getElementById('editDefiModal');
const addBadgeModal = document.getElementById('addBadgeModal');

document.getElementById('openAddDefiModal')  ?.addEventListener('click', () => addDefiModal.style.display  = 'flex');
document.getElementById('openAddBadgeModal') ?.addEventListener('click', () => addBadgeModal.style.display = 'flex');
document.getElementById('closeDefiModal')    ?.addEventListener('click', () => addDefiModal.style.display  = 'none');
document.getElementById('closeEditDefiModal')?.addEventListener('click', () => editDefiModal.style.display = 'none');
document.getElementById('closeBadgeModal')   ?.addEventListener('click', () => addBadgeModal.style.display = 'none');

window.addEventListener('click', e => {
    if (e.target === addDefiModal)  addDefiModal.style.display  = 'none';
    if (e.target === editDefiModal) editDefiModal.style.display = 'none';
    if (e.target === addBadgeModal) addBadgeModal.style.display = 'none';
});

function openEditDefi(id, titre, type, points, dateDebut, dateFin) {
    document.getElementById('editDefiId').value        = id;
    document.getElementById('editDefiTitre').value     = titre;
    document.getElementById('editDefiType').value      = type;
    document.getElementById('editDefiPoints').value    = points;
    document.getElementById('editDefiDateDebut').value = dateDebut;
    document.getElementById('editDefiDateFin').value   = dateFin;
    editDefiModal.style.display = 'flex';
}

// Confirmations suppression
document.querySelectorAll('.btn-delete-confirm').forEach(btn => {
    btn.addEventListener('click', e => {
        if (!confirm('Confirmer la suppression ?')) e.preventDefault();
    });
});

// Chart engagement (dashboard only)
<?php if ($tab === 'dashboard'): ?>
const ctx = document.getElementById('engagementChart')?.getContext('2d');
if (ctx) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4'],
            datasets: [{
                label: 'Participants actifs',
                data: [
                    <?php echo max(0, $statsDefis['participants'] - 3); ?>,
                    <?php echo max(0, $statsDefis['participants'] - 1); ?>,
                    <?php echo $statsDefis['participants']; ?>,
                    <?php echo $statsDefis['participants'] + 2; ?>
                ],
                borderColor: '#4CAF50',
                backgroundColor: 'rgba(76,175,80,0.1)',
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#29B6F6',
                pointRadius: 5
            }]
        },
        options: { responsive: true, maintainAspectRatio: true }
    });
}
<?php endif; ?>
</script>

<script src="../JS/gamification.js"></script>
</body>
</html>
