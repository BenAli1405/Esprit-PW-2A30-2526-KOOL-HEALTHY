// ========== DONNÉES ==========
// Structure conforme au diagramme: Recette, Ingrédient, Recette_Ingrédient, Avis

let ingredientsDB = [
  { id: 1, nom: "Pois chiches", calories: "139kcal/100g", ecoScore: "A" },
  { id: 2, nom: "Quinoa", calories: "120kcal/100g", ecoScore: "A" },
  { id: 3, nom: "Kale", calories: "49kcal/100g", ecoScore: "A+" },
  { id: 4, nom: "Lentilles vertes", calories: "116kcal/100g", ecoScore: "A" },
  { id: 5, nom: "Tofu fermier", calories: "76kcal/100g", ecoScore: "A" },
  { id: 6, nom: "Avocat", calories: "160kcal/100g", ecoScore: "B" },
  { id: 7, nom: "Pomme locale", calories: "52kcal", ecoScore: "A" },
  { id: 8, nom: "Patate douce", calories: "86kcal/100g", ecoScore: "A" }
];

let recettesDB = [
  {
    id: 1,
    titre: "Buddha Bowl pois chiches & quinoa",
    instruction: "Mélanger pois chiches rôtis, quinoa cuit, kale frais. Ajouter sauce tahini et citron.",
    temp: 25,
    difficulte: "Facile",
    ecoScore: "A",
    ingredients: [
      { idIng: 1, qty: 150, unite: "g" },
      { idIng: 2, qty: 100, unite: "g" },
      { idIng: 3, qty: 50, unite: "g" }
    ],
    avis: [
      { id: 1, utilisateur: "Sophie M.", note: 5, commentaire: "Délicieux et rassasiant !" },
      { id: 2, utilisateur: "Thomas L.", note: 4, commentaire: "Très bon, facile à préparer." }
    ]
  },
  {
    id: 2,
    titre: "Soupe de lentilles corail",
    instruction: "Cuire les lentilles avec carottes, oignon, lait de coco. Mixer et servir chaud.",
    temp: 30,
    difficulte: "Facile",
    ecoScore: "A",
    ingredients: [{ idIng: 4, qty: 200, unite: "g" }],
    avis: [
      { id: 1, utilisateur: "Marie D.", note: 5, commentaire: "Soupe réconfortante et healthy !" }
    ]
  },
  {
    id: 3,
    titre: "Tartine avocat & graines",
    instruction: "Écraser l'avocat sur du pain complet toasté, ajouter graines de chanvre, citron, sel et poivre.",
    temp: 10,
    difficulte: "Facile",
    ecoScore: "A+",
    ingredients: [{ idIng: 6, qty: 100, unite: "g" }],
    avis: []
  },
  {
    id: 4,
    titre: "Tofu mariné aux épices",
    instruction: "Mariner le tofu dans sauce soja, gingembre, ail. Cuire à la poêle 10 min.",
    temp: 20,
    difficulte: "Moyen",
    ecoScore: "A",
    ingredients: [{ idIng: 5, qty: 200, unite: "g" }],
    avis: [{ id: 1, utilisateur: "Julien R.", note: 4, commentaire: "Très bon, épices parfaites." }]
  },
  {
    id: 5,
    titre: "Patates douces rôties au romarin",
    instruction: "Couper les patates en cubes, mélanger avec huile d'olive et romarin. Enfourner 25 min à 200°C.",
    temp: 35,
    difficulte: "Facile",
    ecoScore: "A",
    ingredients: [{ idIng: 8, qty: 500, unite: "g" }],
    avis: []
  }
];

let nextAvisId = 10;
let currentUser = "Sophie Martin";

// ========== FONCTIONS UTILITAIRES ==========
function getIngredientName(id) {
  let ing = ingredientsDB.find(i => i.id === id);
  return ing ? ing.nom : "?";
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  const toastMessage = document.getElementById('toastMessage');
  toastMessage.textContent = message;
  toast.style.background = isError ? '#d32f2f' : 'var(--vert-kool-dark)';
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// Calculer la moyenne des notes pour une recette
function getAverageRating(recette) {
  if (!recette.avis || recette.avis.length === 0) return null;
  const sum = recette.avis.reduce((acc, a) => acc + a.note, 0);
  return (sum / recette.avis.length).toFixed(1);
}

// Rendu des étoiles
function renderStars(note) {
  let stars = '';
  for (let i = 1; i <= 5; i++) {
    stars += `<i class="fas fa-star" style="color: ${i <= note ? '#ffc107' : '#ddd'}; font-size: 0.7rem;"></i>`;
  }
  return stars;
}

// ========== RENDU DES RECETTES ==========
function renderRecipes() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const diffFilter = document.getElementById('difficultyFilter').value;
  const ecoFilter = document.getElementById('ecoScoreFilter').value;
  const timeFilter = parseInt(document.getElementById('timeFilter').value);

  let filtered = recettesDB.filter(rec => {
    const matchTitle = rec.titre.toLowerCase().includes(searchTerm);
    const matchIng = rec.ingredients.some(ing => getIngredientName(ing.idIng).toLowerCase().includes(searchTerm));
    const matchSearch = matchTitle || matchIng;
    const matchDiff = diffFilter === "" || rec.difficulte === diffFilter;
    const matchEco = ecoFilter === "" || rec.ecoScore === ecoFilter;
    const matchTime = !timeFilter || rec.temp <= timeFilter;
    return matchSearch && matchDiff && matchEco && matchTime;
  });

  const container = document.getElementById('recipesContainer');
  if (!container) return;

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-search"></i>
        <h3>Aucune recette trouvée</h3>
        <p>Essayez d'autres critères de recherche</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(rec => {
    const avgRating = getAverageRating(rec);
    return `
      <div class="recipe-card" data-recipe-id="${rec.id}">
        <div class="recipe-header">
          <h3>${escapeHtml(rec.titre)}</h3>
          <span class="eco-badge">🌱 Éco-score ${rec.ecoScore}</span>
        </div>
        <div class="recipe-body">
          <div class="recipe-meta">
            <span><i class="fas fa-clock"></i> ${rec.temp} min</span>
            <span><i class="fas fa-chart-simple"></i> ${rec.difficulte}</span>
          </div>
          <p class="recipe-instruction">${escapeHtml(rec.instruction.substring(0, 100))}${rec.instruction.length > 100 ? '…' : ''}</p>
          <div class="ingredients-list">
            <strong><i class="fas fa-carrot"></i> Ingrédients :</strong>
            ${rec.ingredients.map(ing => `<span class="ingredient-item">${getIngredientName(ing.idIng)} (${ing.qty}${ing.unite})</span>`).join('')}
          </div>
          <div class="reviews-section">
            <div class="reviews-header">
              <span><i class="fas fa-comment-dots"></i> Avis</span>
              ${avgRating ? `<span class="average-rating">${renderStars(parseFloat(avgRating))} (${avgRating}/5)</span>` : '<span class="average-rating">⭐ Aucun avis</span>'}
            </div>
            ${rec.avis.slice(0, 2).map(avis => `
              <div class="review-item">
                <div class="review-user">
                  <i class="fas fa-user-circle"></i> ${escapeHtml(avis.utilisateur)}
                  <span class="review-stars">${renderStars(avis.note)}</span>
                </div>
                <p class="review-comment">"${escapeHtml(avis.commentaire)}"</p>
              </div>
            `).join('')}
            ${rec.avis.length > 2 ? `<small style="color:var(--gris-texte); font-size:0.7rem;">+${rec.avis.length - 2} autre(s) avis</small>` : ''}
            <button class="btn-review" data-id="${rec.id}">
              <i class="fas fa-star"></i> Donner mon avis
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  // Attacher événements aux boutons d'avis
  document.querySelectorAll('.btn-review').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const recipeId = parseInt(btn.dataset.id);
      openReviewModal(recipeId);
    });
  });
}

// ========== MODAL AVIS ==========
let currentReviewRecipeId = null;
let currentRecipeTitle = null;

function openReviewModal(recipeId) {
  const recipe = recettesDB.find(r => r.id === recipeId);
  if (!recipe) return;
  
  currentReviewRecipeId = recipeId;
  currentRecipeTitle = recipe.titre;
  
  document.getElementById('reviewRecipeTitle').textContent = recipe.titre;
  document.getElementById('selectedRating').value = '0';
  document.getElementById('reviewComment').value = '';
  
  // Réinitialiser les étoiles
  document.querySelectorAll('.star-rating').forEach(star => {
    star.classList.remove('active');
    star.classList.add('far');
    star.classList.remove('fas');
  });
  
  document.getElementById('reviewModal').style.display = 'flex';
}

// Gestion des étoiles
document.querySelectorAll('.star-rating').forEach(star => {
  star.addEventListener('click', function() {
    const value = parseInt(this.dataset.value);
    document.getElementById('selectedRating').value = value;
    
    document.querySelectorAll('.star-rating').forEach((s, index) => {
      if (index < value) {
        s.classList.add('active');
        s.classList.remove('far');
        s.classList.add('fas');
      } else {
        s.classList.remove('active');
        s.classList.remove('fas');
        s.classList.add('far');
      }
    });
  });
});

// Soumettre l'avis
document.getElementById('submitReviewBtn').addEventListener('click', () => {
  const rating = parseInt(document.getElementById('selectedRating').value);
  const comment = document.getElementById('reviewComment').value.trim();
  
  if (rating === 0) {
    showToast('Veuillez sélectionner une note', true);
    return;
  }
  
  if (!comment) {
    showToast('Veuillez ajouter un commentaire', true);
    return;
  }
  
  const recipe = recettesDB.find(r => r.id === currentReviewRecipeId);
  if (recipe) {
    recipe.avis.push({
      id: nextAvisId++,
      utilisateur: currentUser,
      note: rating,
      commentaire: comment
    });
    showToast('Merci pour votre avis !');
    renderRecipes();
  }
  
  document.getElementById('reviewModal').style.display = 'none';
});

// Fermeture modale
document.getElementById('closeReviewModal').onclick = () => {
  document.getElementById('reviewModal').style.display = 'none';
};
document.getElementById('cancelReviewBtn').onclick = () => {
  document.getElementById('reviewModal').style.display = 'none';
};
window.onclick = (e) => {
  if (e.target === document.getElementById('reviewModal')) {
    document.getElementById('reviewModal').style.display = 'none';
  }
};

// ========== FILTRES ==========
document.getElementById('resetFiltersBtn').addEventListener('click', () => {
  document.getElementById('searchInput').value = '';
  document.getElementById('difficultyFilter').value = '';
  document.getElementById('ecoScoreFilter').value = '';
  document.getElementById('timeFilter').value = '';
  renderRecipes();
});

document.getElementById('searchInput').addEventListener('input', () => renderRecipes());
document.getElementById('difficultyFilter').addEventListener('change', () => renderRecipes());
document.getElementById('ecoScoreFilter').addEventListener('change', () => renderRecipes());
document.getElementById('timeFilter').addEventListener('change', () => renderRecipes());

// ========== INITIALISATION ==========
renderRecipes();