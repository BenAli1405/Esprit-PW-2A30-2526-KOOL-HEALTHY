// ========== DONNÉES ==========
let ingredientsDB = [
  { id: 1, nom: "Pois chiches", calories: "139kcal/100g", ecoScore: "A" },
  { id: 2, nom: "Quinoa", calories: "120kcal/100g", ecoScore: "A" },
  { id: 3, nom: "Kale", calories: "49kcal/100g", ecoScore: "A+" },
  { id: 4, nom: "Lentilles vertes", calories: "116kcal/100g", ecoScore: "A" },
  { id: 5, nom: "Tofu fermier", calories: "76kcal/100g", ecoScore: "A" },
  { id: 6, nom: "Avocat", calories: "160kcal/100g", ecoScore: "B" },
  { id: 7, nom: "Pomme locale", calories: "52kcal", ecoScore: "A" },
  { id: 8, nom: "Patate douce", calories: "86kcal/100g", ecoScore: "A" }
];

let recettesDB = [
  {
    id: 1, utilisateurId: 1, titre: "Buddha Bowl pois chiches & quinoa",
    instruction: "Mélanger pois chiches, quinoa, kale, sauce tahini.",
    temp: 25, difficulte: "Facile", ecoScore: "A",
    ingredients: [{ idIng: 1, qty: 150, unite: "g" }, { idIng: 2, qty: 100, unite: "g" }, { idIng: 3, qty: 50, unite: "g" }],
    avis: [{ id: 1, utilisateurId: 2, utilisateurNom: "Sophie M.", note: 5, commentaire: "Délicieux !", date: "2025-03-15" }]
  },
  {
    id: 2, utilisateurId: 1, titre: "Soupe de lentilles corail",
    instruction: "Cuire les lentilles avec carottes, lait de coco.",
    temp: 30, difficulte: "Facile", ecoScore: "A",
    ingredients: [{ idIng: 4, qty: 200, unite: "g" }],
    avis: [{ id: 2, utilisateurId: 3, utilisateurNom: "Marie D.", note: 5, commentaire: "Réconfortante", date: "2025-03-20" }]
  },
  {
    id: 3, utilisateurId: 2, titre: "Tartine avocat & graines",
    instruction: "Écraser l'avocat sur du pain complet.",
    temp: 10, difficulte: "Facile", ecoScore: "A+",
    ingredients: [{ idIng: 6, qty: 100, unite: "g" }],
    avis: []
  },
  {
    id: 4, utilisateurId: 1, titre: "Tofu mariné aux épices",
    instruction: "Mariner le tofu, cuire à la poêle.",
    temp: 20, difficulte: "Moyen", ecoScore: "A",
    ingredients: [{ idIng: 5, qty: 200, unite: "g" }],
    avis: [{ id: 3, utilisateurId: 2, utilisateurNom: "Julien R.", note: 4, commentaire: "Très bon", date: "2025-03-18" }]
  },
  {
    id: 5, utilisateurId: 3, titre: "Patates douces rôties",
    instruction: "Couper en cubes, ajouter romarin, enfourner.",
    temp: 35, difficulte: "Facile", ecoScore: "A",
    ingredients: [{ idIng: 8, qty: 500, unite: "g" }],
    avis: []
  }
];

let usersDB = [
  { id: 1, nom: "Admin Kool", email: "admin@koolhealthy.com", dateInscription: "2024-01-01", statut: "actif", recettesCrees: [1, 2, 4], avisDonnes: [] },
  { id: 2, nom: "Sophie Martin", email: "sophie@email.com", dateInscription: "2024-02-15", statut: "actif", recettesCrees: [3], avisDonnes: [1, 3] },
  { id: 3, nom: "Marie Dubois", email: "marie@email.com", dateInscription: "2024-03-10", statut: "actif", recettesCrees: [5], avisDonnes: [2] },
  { id: 4, nom: "Thomas Leroy", email: "thomas@email.com", dateInscription: "2024-04-05", statut: "bloque", recettesCrees: [], avisDonnes: [] }
];

let nextRecipeId = 6;
let nextIngredientId = 9;
let nextReviewId = 4;

// ========== UTILITAIRES ==========
function getIngredientName(id) {
  let ing = ingredientsDB.find(i => i.id === id);
  return ing ? ing.nom : "?";
}

function getIngredientUsageCount(id) {
  let count = 0;
  recettesDB.forEach(rec => {
    if (rec.ingredients.some(ing => ing.idIng === id)) count++;
  });
  return count;
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  const toastMessage = document.getElementById('toastMessage');
  toastMessage.textContent = message;
  toast.style.background = isError ? '#ef5350' : 'var(--vert-kool-dark)';
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function renderStars(note) {
  let stars = '';
  for (let i = 1; i <= 5; i++) {
    stars += `<i class="fas fa-star" style="color: ${i <= note ? '#ffc107' : '#ddd'}; font-size: 0.7rem;"></i>`;
  }
  return stars;
}

// ========== DASHBOARD ==========
function updateDashboard() {
  document.getElementById('statRecettes').textContent = recettesDB.length;
  document.getElementById('statIngredients').textContent = ingredientsDB.length;
  document.getElementById('statUsers').textContent = usersDB.length;
  
  let totalReviews = 0;
  recettesDB.forEach(rec => totalReviews += rec.avis.length);
  document.getElementById('statReviews').textContent = totalReviews;
  
  // Top recettes par note moyenne
  let recettesWithAvg = recettesDB.map(rec => {
    let avg = rec.avis.length ? rec.avis.reduce((s, a) => s + a.note, 0) / rec.avis.length : 0;
    return { ...rec, avgNote: avg };
  });
  recettesWithAvg.sort((a, b) => b.avgNote - a.avgNote);
  const topRecipes = recettesWithAvg.slice(0, 5);
  const topRecipesHtml = topRecipes.map(rec => `
    <div class="top-item">
      <span class="top-item-name">${escapeHtml(rec.titre)}</span>
      <span class="top-item-value">⭐ ${rec.avgNote.toFixed(1)}/5 (${rec.avis.length} avis)</span>
    </div>
  `).join('');
  document.getElementById('topRecipesList').innerHTML = topRecipesHtml || '<div>Aucune recette avec avis</div>';
  
  // Top ingrédients les plus utilisés
  let ingredientCount = {};
  recettesDB.forEach(rec => {
    rec.ingredients.forEach(ing => {
      ingredientCount[ing.idIng] = (ingredientCount[ing.idIng] || 0) + 1;
    });
  });
  let topIngredients = Object.entries(ingredientCount)
    .map(([id, count]) => ({ id: parseInt(id), nom: getIngredientName(parseInt(id)), count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  const topIngredientsHtml = topIngredients.map(ing => `
    <div class="top-item">
      <span class="top-item-name">${escapeHtml(ing.nom)}</span>
      <span class="top-item-value">${ing.count} recettes</span>
    </div>
  `).join('');
  document.getElementById('topIngredientsList').innerHTML = topIngredientsHtml || '<div>Aucun ingrédient utilisé</div>';
  
  // Activité récente (derniers avis)
  let allReviews = [];
  recettesDB.forEach(rec => {
    rec.avis.forEach(avis => {
      allReviews.push({ recetteTitre: rec.titre, ...avis });
    });
  });
  allReviews.sort((a, b) => new Date(b.date) - new Date(a.date));
  const recentReviews = allReviews.slice(0, 5);
  const recentHtml = recentReviews.map(rev => `
    <div class="activity-item">
      <div class="activity-icon"><i class="fas fa-star"></i></div>
      <div class="activity-detail">
        <p><strong>${escapeHtml(rev.utilisateurNom)}</strong> a noté "${escapeHtml(rev.recetteTitre)}" ${renderStars(rev.note)}</p>
        <small>${rev.date}</small>
      </div>
    </div>
  `).join('');
  document.getElementById('recentActivityList').innerHTML = recentHtml || '<div>Aucun avis récent</div>';
}

// ========== GESTION RECETTES ==========
function renderRecipesTable() {
  const tbody = document.getElementById('recipesTableBody');
  tbody.innerHTML = recettesDB.map(rec => `
    <tr>
      <td>${rec.id}</td>
      <td>${escapeHtml(rec.titre)}</td>
      <td>${rec.difficulte}</td>
      <td>${rec.temp} min</td>
      <td><span class="status-active">${rec.ecoScore}</span></td>
      <td>${rec.ingredients.map(ing => `${getIngredientName(ing.idIng)} (${ing.qty}${ing.unite})`).join(', ')}</td>
      <td class="action-icons">
        <i class="fas fa-edit edit-icon" data-type="recipe" data-id="${rec.id}"></i>
        <i class="fas fa-trash-alt delete-icon" data-type="recipe" data-id="${rec.id}"></i>
      </td>
    </tr>
  `).join('');
  
  document.querySelectorAll('.edit-icon[data-type="recipe"]').forEach(btn => {
    btn.addEventListener('click', () => openRecipeModal(parseInt(btn.dataset.id)));
  });
  document.querySelectorAll('.delete-icon[data-type="recipe"]').forEach(btn => {
    btn.addEventListener('click', () => deleteRecipe(parseInt(btn.dataset.id)));
  });
}

function openRecipeModal(recipeId = null) {
  const modal = document.getElementById('recipeModal');
  document.getElementById('recipeId').value = '';
  document.getElementById('recipeTitle').value = '';
  document.getElementById('recipeInstructions').value = '';
  document.getElementById('recipeTime').value = 30;
  document.getElementById('recipeDifficulty').value = 'Facile';
  document.getElementById('recipeEcoScore').value = 'A';
  document.getElementById('ingredientsListContainer').innerHTML = '';
  
  if (recipeId) {
    const rec = recettesDB.find(r => r.id === recipeId);
    if (rec) {
      document.getElementById('recipeModalTitle').innerHTML = '<i class="fas fa-edit"></i> Modifier la recette';
      document.getElementById('recipeId').value = rec.id;
      document.getElementById('recipeTitle').value = rec.titre;
      document.getElementById('recipeInstructions').value = rec.instruction;
      document.getElementById('recipeTime').value = rec.temp;
      document.getElementById('recipeDifficulty').value = rec.difficulte;
      document.getElementById('recipeEcoScore').value = rec.ecoScore;
      rec.ingredients.forEach(ing => addIngredientRowToModal(ing.idIng, ing.qty, ing.unite));
    }
  } else {
    document.getElementById('recipeModalTitle').innerHTML = '<i class="fas fa-plus-circle"></i> Ajouter une recette';
  }
  modal.style.display = 'flex';
}

function addIngredientRowToModal(selectedId = null, qty = 100, unite = 'g') {
  const container = document.getElementById('ingredientsListContainer');
  const rowDiv = document.createElement('div');
  rowDiv.className = 'ingredient-row';
  const select = document.createElement('select');
  select.innerHTML = '<option value="">-- Choisir --</option>' + ingredientsDB.map(ing => `<option value="${ing.id}" ${selectedId === ing.id ? 'selected' : ''}>${ing.nom} (${ing.ecoScore})</option>`).join('');
  const qtyInput = document.createElement('input');
  qtyInput.type = 'number';
  qtyInput.value = qty;
  qtyInput.placeholder = 'Qté';
  qtyInput.style.width = '80px';
  const uniteInput = document.createElement('input');
  uniteInput.type = 'text';
  uniteInput.value = unite;
  uniteInput.placeholder = 'unité';
  uniteInput.style.width = '80px';
  const removeBtn = document.createElement('button');
  removeBtn.innerHTML = '<i class="fas fa-times-circle"></i>';
  removeBtn.onclick = () => rowDiv.remove();
  rowDiv.appendChild(select);
  rowDiv.appendChild(qtyInput);
  rowDiv.appendChild(uniteInput);
  rowDiv.appendChild(removeBtn);
  container.appendChild(rowDiv);
}

function deleteRecipe(id) {
  if (confirm('Supprimer cette recette ? Tous les avis associés seront supprimés.')) {
    recettesDB = recettesDB.filter(r => r.id !== id);
    renderRecipesTable();
    updateDashboard();
    showToast('Recette supprimée');
  }
}

document.getElementById('recipeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const id = parseInt(document.getElementById('recipeId').value);
  const titre = document.getElementById('recipeTitle').value;
  const instruction = document.getElementById('recipeInstructions').value;
  const temp = parseInt(document.getElementById('recipeTime').value);
  const difficulte = document.getElementById('recipeDifficulty').value;
  const ecoScore = document.getElementById('recipeEcoScore').value;
  
  const ingredientRows = document.querySelectorAll('#ingredientsListContainer .ingredient-row');
  let ingredients = [];
  ingredientRows.forEach(row => {
    const select = row.querySelector('select');
    const qtyInput = row.querySelector('input[type="number"]');
    const uniteInput = row.querySelectorAll('input[type="text"]')[0];
    if (select.value) {
      ingredients.push({ idIng: parseInt(select.value), qty: parseFloat(qtyInput.value) || 0, unite: uniteInput.value || 'g' });
    }
  });
  
  if (id) {
    const index = recettesDB.findIndex(r => r.id === id);
    if (index !== -1) {
      recettesDB[index] = { ...recettesDB[index], titre, instruction, temp, difficulte, ecoScore, ingredients };
    }
    showToast('Recette modifiée');
  } else {
    recettesDB.push({ id: nextRecipeId++, utilisateurId: 1, titre, instruction, temp, difficulte, ecoScore, ingredients, avis: [] });
    showToast('Recette ajoutée');
  }
  document.getElementById('recipeModal').style.display = 'none';
  renderRecipesTable();
  updateDashboard();
});

// ========== GESTION INGREDIENTS ==========
function renderIngredientsTable() {
  const tbody = document.getElementById('ingredientsTableBody');
  tbody.innerHTML = ingredientsDB.map(ing => `
    <tr>
      <td>${ing.id}</td>
      <td>${escapeHtml(ing.nom)}</td>
      <td>${ing.calories}</td>
      <td><span class="status-active">${ing.ecoScore}</span></td>
      <td>${getIngredientUsageCount(ing.id)} recettes</td>
      <td class="action-icons">
        <i class="fas fa-edit edit-icon" data-type="ingredient" data-id="${ing.id}"></i>
        <i class="fas fa-trash-alt delete-icon" data-type="ingredient" data-id="${ing.id}"></i>
      </td>
    </tr>
  `).join('');
  
  document.querySelectorAll('.edit-icon[data-type="ingredient"]').forEach(btn => {
    btn.addEventListener('click', () => openIngredientModal(parseInt(btn.dataset.id)));
  });
  document.querySelectorAll('.delete-icon[data-type="ingredient"]').forEach(btn => {
    btn.addEventListener('click', () => deleteIngredient(parseInt(btn.dataset.id)));
  });
}

function openIngredientModal(ingredientId = null) {
  const modal = document.getElementById('ingredientModal');
  document.getElementById('ingredientId').value = '';
  document.getElementById('ingredientName').value = '';
  document.getElementById('ingredientCalories').value = '';
  document.getElementById('ingredientEcoScore').value = 'A';
  
  if (ingredientId) {
    const ing = ingredientsDB.find(i => i.id === ingredientId);
    if (ing) {
      document.getElementById('ingredientModalTitle').innerHTML = '<i class="fas fa-edit"></i> Modifier l\'ingrédient';
      document.getElementById('ingredientId').value = ing.id;
      document.getElementById('ingredientName').value = ing.nom;
      document.getElementById('ingredientCalories').value = ing.calories;
      document.getElementById('ingredientEcoScore').value = ing.ecoScore;
    }
  } else {
    document.getElementById('ingredientModalTitle').innerHTML = '<i class="fas fa-plus-circle"></i> Ajouter un ingrédient';
  }
  modal.style.display = 'flex';
}

function deleteIngredient(id) {
  const usageCount = getIngredientUsageCount(id);
  if (usageCount > 0) {
    if (!confirm(`Cet ingrédient est utilisé dans ${usageCount} recette(s). Le supprimer le retirera de ces recettes. Continuer ?`)) return;
    recettesDB.forEach(rec => {
      rec.ingredients = rec.ingredients.filter(ing => ing.idIng !== id);
    });
  }
  ingredientsDB = ingredientsDB.filter(i => i.id !== id);
  renderIngredientsTable();
  renderRecipesTable();
  updateDashboard();
  showToast('Ingrédient supprimé');
}

document.getElementById('ingredientForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const id = parseInt(document.getElementById('ingredientId').value);
  const nom = document.getElementById('ingredientName').value;
  const calories = document.getElementById('ingredientCalories').value;
  const ecoScore = document.getElementById('ingredientEcoScore').value;
  
  if (id) {
    const index = ingredientsDB.findIndex(i => i.id === id);
    if (index !== -1) ingredientsDB[index] = { ...ingredientsDB[index], nom, calories, ecoScore };
    showToast('Ingrédient modifié');
  } else {
    ingredientsDB.push({ id: nextIngredientId++, nom, calories, ecoScore });
    showToast('Ingrédient ajouté');
  }
  document.getElementById('ingredientModal').style.display = 'none';
  renderIngredientsTable();
  renderRecipesTable();
});

// ========== GESTION UTILISATEURS ==========
function renderUsersTable() {
  const tbody = document.getElementById('usersTableBody');
  tbody.innerHTML = usersDB.map(user => `
    <tr>
      <td>${user.id}</td>
      <td>${escapeHtml(user.nom)}</td>
      <td>${user.email}</td>
      <td>${user.dateInscription}</td>
      <td>${user.recettesCrees.length}</td>
      <td>${user.avisDonnes.length}</td>
      <td><span class="${user.statut === 'actif' ? 'status-active' : 'status-blocked'}">${user.statut === 'actif' ? 'Actif' : 'Bloqué'}</span></td>
      <td class="action-icons">
        ${user.statut === 'actif' ? '<i class="fas fa-ban block-icon" data-type="block" data-id="' + user.id + '" title="Bloquer"></i>' : '<i class="fas fa-check-circle block-icon" data-type="unblock" data-id="' + user.id + '" title="Débloquer" style="color:var(--vert-kool);"></i>'}
        <i class="fas fa-info-circle edit-icon" data-type="user" data-id="${user.id}" title="Voir activités"></i>
      </td>
    </tr>
  `).join('');
  
  document.querySelectorAll('.block-icon').forEach(btn => {
    btn.addEventListener('click', () => toggleUserBlock(parseInt(btn.dataset.id), btn.dataset.type === 'block'));
  });
  document.querySelectorAll('.edit-icon[data-type="user"]').forEach(btn => {
    btn.addEventListener('click', () => showUserActivities(parseInt(btn.dataset.id)));
  });
}

function toggleUserBlock(userId, block) {
  const user = usersDB.find(u => u.id === userId);
  if (user) {
    user.statut = block ? 'bloque' : 'actif';
    showToast(block ? 'Utilisateur bloqué' : 'Utilisateur débloqué');
    renderUsersTable();
  }
}

function showUserActivities(userId) {
  const user = usersDB.find(u => u.id === userId);
  if (!user) return;
  const userRecettes = recettesDB.filter(r => r.utilisateurId === userId);
  const userReviews = [];
  recettesDB.forEach(rec => {
    rec.avis.forEach(avis => {
      if (avis.utilisateurId === userId) userReviews.push({ recetteTitre: rec.titre, ...avis });
    });
  });
  let message = `📊 Activités de ${user.nom}\n\n`;
  message += `📝 Recettes créées (${userRecettes.length}):\n${userRecettes.map(r => `- ${r.titre}`).join('\n') || 'Aucune'}\n\n`;
  message += `⭐ Avis donnés (${userReviews.length}):\n${userReviews.map(r => `- "${r.recetteTitre}" : ${r.note}/5`).join('\n') || 'Aucun'}`;
  alert(message);
}

// ========== GESTION AVIS ==========
function renderReviewsTable() {
  const tbody = document.getElementById('reviewsTableBody');
  let allReviews = [];
  recettesDB.forEach(rec => {
    rec.avis.forEach(avis => {
      allReviews.push({ recetteId: rec.id, recetteTitre: rec.titre, ...avis });
    });
  });
  allReviews.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  tbody.innerHTML = allReviews.map(rev => `
    <tr>
      <td>${rev.id}</td>
      <td>${escapeHtml(rev.recetteTitre)}</td>
      <td>${escapeHtml(rev.utilisateurNom)}</td>
      <td>${renderStars(rev.note)} (${rev.note}/5)</td>
      <td>${escapeHtml(rev.commentaire.substring(0, 60))}${rev.commentaire.length > 60 ? '…' : ''}</td>
      <td>${rev.date}</td>
      <td class="action-icons">
        <i class="fas fa-trash-alt delete-icon" data-type="review" data-recipe="${rev.recetteId}" data-id="${rev.id}"></i>
      </td>
    </tr>
  `).join('');
  
  document.querySelectorAll('.delete-icon[data-type="review"]').forEach(btn => {
    btn.addEventListener('click', () => deleteReview(parseInt(btn.dataset.recipe), parseInt(btn.dataset.id)));
  });
}

function deleteReview(recipeId, reviewId) {
  if (confirm('Supprimer cet avis ?')) {
    const recipe = recettesDB.find(r => r.id === recipeId);
    if (recipe) {
      recipe.avis = recipe.avis.filter(a => a.id !== reviewId);
      renderReviewsTable();
      renderRecipesTable();
      updateDashboard();
      showToast('Avis supprimé');
    }
  }
}

// ========== NAVIGATION TABS ==========
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

const contents = {
  dashboard: document.getElementById('dashboardContent'),
  recipes: document.getElementById('recipesContent'),
  ingredients: document.getElementById('ingredientsContent'),
  users: document.getElementById('usersContent'),
  reviews: document.getElementById('reviewsContent')
};

function showTab(tabId) {
  Object.keys(contents).forEach(k => { if (contents[k]) contents[k].style.display = 'none'; });
  if (contents[tabId]) contents[tabId].style.display = 'block';
}

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    const tab = item.getAttribute('data-tab');
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    item.classList.add('active');
    showTab(tab);
    if (tab === 'recipes') renderRecipesTable();
    if (tab === 'ingredients') renderIngredientsTable();
    if (tab === 'users') renderUsersTable();
    if (tab === 'reviews') renderReviewsTable();
    if (tab === 'dashboard') updateDashboard();
  });
});

// Boutons globaux
document.getElementById('addRecipeBtn').addEventListener('click', () => openRecipeModal());
document.getElementById('globalAddBtn').addEventListener('click', () => openRecipeModal());
document.getElementById('addIngredientBtn').addEventListener('click', () => openIngredientModal());
document.getElementById('addIngredientRowBtn').addEventListener('click', () => addIngredientRowToModal());

// Fermeture modals
document.getElementById('closeRecipeModal').onclick = () => document.getElementById('recipeModal').style.display = 'none';
document.getElementById('closeIngredientModal').onclick = () => document.getElementById('ingredientModal').style.display = 'none';
document.getElementById('cancelRecipeBtn').onclick = () => document.getElementById('recipeModal').style.display = 'none';
document.getElementById('cancelIngredientBtn').onclick = () => document.getElementById('ingredientModal').style.display = 'none';
window.onclick = (e) => {
  if (e.target === document.getElementById('recipeModal')) document.getElementById('recipeModal').style.display = 'none';
  if (e.target === document.getElementById('ingredientModal')) document.getElementById('ingredientModal').style.display = 'none';
};

// INIT
showTab('dashboard');
updateDashboard();