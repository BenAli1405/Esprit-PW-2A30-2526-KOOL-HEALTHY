<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Scanner un produit</title>
  <meta name="description" content="Scannez un produit et obtenez instantanément son éco-score calculé par IA (KNN).">
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ===== SIDEBAR (Tfront style) ===== -->
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>espace nutrition · éco-score IA</p>
    </div>

    <nav class="nav-menu">
      <a href="scan.php"     class="nav-item active"><i class="fas fa-barcode"></i><span>Scanner un produit</span></a>
      <a href="comparer.php" class="nav-item"><i class="fas fa-code-compare"></i><span>Comparer</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user"></i></div>
        <div class="user-info">
          <p>Mon espace</p>
          <small>Produit &amp; Éco-score</small>
        </div>
      </div>
    </div>
  </aside>
  <!-- ===== END SIDEBAR ===== -->

  <!-- ===== MAIN ===== -->
  <main class="main-content">

    <!-- Top bar -->
    <div class="top-bar">
      <div class="page-title">
        <h1><i class="fas fa-barcode" style="color:var(--bleu-tech);font-size:1.2rem;"></i> Analyser un produit</h1>
        <p>Entrez un code-barres ou un nom de produit pour obtenir son éco-score IA</p>
      </div>
      <div class="header-actions">
        <a href="comparer.php" class="btn btn-outline"><i class="fas fa-code-compare"></i> Comparer</a>
        <!-- PHP INTEGRATION: lien admin conditionné au rôle -->
        <a href="liste_produits.php" class="btn btn-primary"><i class="fas fa-shield-halved"></i> Admin</a>
      </div>
    </div>

    <div class="dashboard-container">

      <!-- ── Formulaire de scan ── -->
      <div class="card-panel">
        <div class="panel-header">
          <h3><i class="fas fa-magnifying-glass"></i> Recherche produit</h3>
          <span class="badge-tech">Open Food Facts · IA KNN</span>
        </div>

        <!-- PHP INTEGRATION: action="scan.php" method="POST" -->
        <form id="scanForm" action="scan.php" method="POST" class="search-form">
          <input
            type="text"
            id="barcode"
            name="barcode"
            class="form-control"
            placeholder="Code-barres ou nom du produit... ex: 3017620422003"
            required
            autocomplete="off"
            <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($_POST['barcode'] ?? ''); ?>" -->
          >
          <button type="submit" class="btn btn-primary" id="scanSubmitBtn">
            <i class="fas fa-magnifying-glass"></i> Analyser
          </button>
        </form>
      </div>

      <!-- ── RÉSULTAT ─────────────────────────────────────────────────────────
           PHP INTEGRATION: entourer tout ce bloc avec
           <?php if (isset($produit)): ?>
      ─────────────────────────────────────────────────────────────────────── -->
      <div class="two-columns">

        <!-- Identité + éco-score -->
        <div class="card-panel result-section">
          <div class="panel-header">
            <h3><i class="fas fa-leaf"></i> Résultat de l'analyse</h3>
            <span class="badge-eco">Éco-score IA</span>
          </div>

          <!-- PHP INTEGRATION: echo htmlspecialchars($produit['nom']); -->
          <h2 style="font-size:1.3rem; margin-bottom:6px;">Pâtes complètes Bio</h2>
          <!-- PHP INTEGRATION: echo $produit['marque'] . ' · ' . $produit['categorie']; -->
          <p class="text-muted" style="font-size:0.85rem; margin-bottom:20px;">Panzani · Épicerie</p>

          <div style="margin-bottom:24px;">
            <!-- PHP INTEGRATION: class="eco-badge score-<?php echo $score; ?>" -->
            <div class="eco-badge score-B">B</div>
          </div>

          <h4 style="font-size:0.82rem; font-weight:600; color:var(--gris-texte); margin-bottom:6px;">SCORE GLOBAL (KNN)</h4>
          <!-- PHP INTEGRATION: style="width:<?php echo $pourcentage; ?>%;" -->
          <div class="progress-bar-bg">
            <div class="progress-fill" style="width:75%;"></div>
          </div>
          <p style="font-size:0.75rem; color:var(--gris-texte); margin-top:4px;">75 / 100 – basé sur les critères environnementaux</p>

          <p style="margin-top:20px; font-size:0.82rem; color:var(--gris-texte); font-style:italic;">
            <i class="fas fa-brain" style="color:var(--bleu-tech);"></i>
            <!-- PHP INTEGRATION: echo $nb_exemples; -->
            Score calculé par IA (KNN) basé sur <strong>15 exemples</strong> similaires.
          </p>
        </div>

        <!-- Critères détaillés -->
        <div class="card-panel">
          <div class="panel-header">
            <h3><i class="fas fa-chart-bar"></i> Critères environnementaux</h3>
            <span class="badge-tech">Normalisés 0–1</span>
          </div>

          <ul class="criteria-list">
            <!-- PHP INTEGRATION: remplacer les valeurs statiques par des variables PHP -->
            <li>
              <span><i class="fas fa-earth-europe"></i> Origine géographique</span>
              <strong>0.20 <small class="text-muted">(Locale)</small></strong>
            </li>
            <li>
              <span><i class="fas fa-box"></i> Emballage</span>
              <strong>0.80 <small class="text-muted">(Plastique)</small></strong>
            </li>
            <li>
              <span><i class="fas fa-industry"></i> Mode de production</span>
              <strong>0.45 <small class="text-muted">(Modéré)</small></strong>
            </li>
          </ul>

          <!-- Recommandation IA -->
          <div class="info-box" style="margin-top:20px;">
            <i class="fas fa-robot"></i>
            <strong>Recommandation IA :</strong> Préférez un emballage recyclable pour améliorer le score d'un niveau.
          </div>
        </div>

      </div><!-- /.two-columns -->
      <!-- PHP INTEGRATION: <?php endif; ?> -->

      <!-- ── Comparaison rapide ── -->
      <div class="card-panel">
        <div class="panel-header">
          <h3><i class="fas fa-code-compare"></i> Comparer rapidement deux produits</h3>
          <a href="comparer.php" class="badge-tech" style="text-decoration:none;">Aller à la comparaison →</a>
        </div>

        <form action="comparer.php" method="POST" class="compare-grid" style="gap:16px;">
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="q_barcode1">Produit 1</label>
            <input type="text" id="q_barcode1" name="barcode1" class="form-control" placeholder="Code-barres ou nom" required>
          </div>
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="q_barcode2">Produit 2</label>
            <input type="text" id="q_barcode2" name="barcode2" class="form-control" placeholder="Code-barres ou nom" required>
          </div>
          <div style="grid-column: 1 / -1;">
            <button type="submit" class="btn btn-outline"><i class="fas fa-scale-balanced"></i> Comparer</button>
          </div>
        </form>
      </div>

    </div><!-- /.dashboard-container -->
  </main>
  <!-- ===== END MAIN ===== -->

</div><!-- /.app-wrapper -->

<script>
  document.getElementById('scanForm').addEventListener('submit', function () {
    const btn = document.getElementById('scanSubmitBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyse en cours…';
    btn.style.opacity = '0.8';
    btn.disabled = true;
  });
</script>
</body>
</html>
