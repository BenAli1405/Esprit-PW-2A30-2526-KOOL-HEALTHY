<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Back-office – Exemples KNN</title>
  <meta name="description" content="Gestion des exemples KNN pour le calcul de l'éco-score par IA.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ===== SIDEBAR ===== -->
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>administration · produit &amp; éco-score</p>
    </div>

    <nav class="nav-menu">
      <div class="nav-section-title">Front-office</div>
      <a href="scan.php"     class="nav-item"><i class="fas fa-barcode"></i><span>Scanner un produit</span></a>
      <a href="comparer.php" class="nav-item"><i class="fas fa-code-compare"></i><span>Comparer</span></a>

      <div class="nav-section-title">Administration</div>
      <a href="liste_produits.php"     class="nav-item active"><i class="fas fa-boxes-stacked"></i><span>Produits</span></a>
      <a href="formulaire_produit.php" class="nav-item"><i class="fas fa-plus-circle"></i><span>Ajouter un produit</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
        <div class="user-info">
          <p>Administrateur</p>
          <small>admin@koolhealthy.com</small>
        </div>
      </div>
    </div>
  </aside>

  <!-- ===== MAIN ===== -->
  <main class="main-content">

    <!-- Top bar -->
    <div class="top-bar">
      <div class="page-title">
        <!-- PHP INTEGRATION: echo "Exemples KNN – " . htmlspecialchars($produit['nom']); -->
        <h1><i class="fas fa-brain" style="color:var(--bleu-tech);font-size:1.2rem;"></i> Exemples KNN – Pâtes complètes Bio</h1>
        <p>Base d'apprentissage de l'IA · valeurs normalisées entre 0.00 et 1.00</p>
      </div>
      <div class="header-actions">
        <a href="liste_produits.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Retour aux produits</a>
        <!-- PHP INTEGRATION: href="formulaire_exemple.php?id_produit=<?php echo $id_produit; ?>" -->
        <a href="formulaire_exemple.php?id_produit=1" class="btn btn-primary">
          <i class="fas fa-plus"></i> Ajouter un exemple
        </a>
      </div>
    </div>

    <div class="dashboard-container">

      <!-- Info banner IA -->
      <div class="info-box info-green" style="margin-bottom:24px;">
        <i class="fas fa-brain"></i>
        <strong>Information KNN :</strong> Ces exemples alimentent l'algorithme d'IA.
        Plus vous en ajoutez, plus les prédictions d'éco-score sont précises.
        Les critères doivent être normalisés entre <strong>0.00</strong> (excellent) et <strong>1.00</strong> (très mauvais).
      </div>

      <!-- Stats -->
      <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(160px,1fr)); margin-bottom:24px;">
        <div class="stat-card">
          <div class="stat-title">Exemples enregistrés</div>
          <!-- PHP INTEGRATION: echo count($exemples); -->
          <div class="stat-value">2</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Score A</div><div class="stat-value" style="color:var(--badge-a);">0</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Score B</div><div class="stat-value" style="color:var(--badge-b);">2</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Score C–E</div><div class="stat-value" style="color:var(--badge-d);">0</div>
        </div>
      </div>

      <!-- Tableau des exemples -->
      <div class="card-panel">
        <div class="panel-header">
          <h3><i class="fas fa-table"></i> Base d'exemples KNN</h3>
          <span class="badge-eco">Données d'entraînement IA</span>
        </div>

        <!-- PHP INTEGRATION: message si aucun exemple
        <?php if (empty($exemples)): ?>
        <div class="info-box" style="text-align:center;">
          <i class="fas fa-database"></i> Aucun exemple pour ce produit.
          <a href="formulaire_exemple.php?id_produit=<?php echo $id_produit; ?>" style="color:var(--bleu-tech); margin-left:8px;">
            Ajouter le premier →
          </a>
        </div>
        <?php else: ?>
        -->

        <div style="overflow-x:auto;">
          <table class="data-table" id="knnTable">
            <thead>
              <tr>
                <th>ID Exemple</th>
                <th>Origine <small>(0–1)</small></th>
                <th>Emballage <small>(0–1)</small></th>
                <th>Production <small>(0–1)</small></th>
                <th class="text-center">Score officiel</th>
                <th>Date d'ajout</th>
                <th style="min-width:140px;">Actions</th>
              </tr>
            </thead>
            <tbody>

              <!-- PHP INTEGRATION: <?php foreach ($exemples as $ex): ?> -->

              <tr>
                <!-- PHP INTEGRATION: echo $ex['id_exemple']; -->
                <td><strong>#101</strong></td>
                <!-- PHP INTEGRATION: echo $ex['origine_norm']; -->
                <td>0.20</td>
                <!-- PHP INTEGRATION: echo $ex['emballage_norm']; -->
                <td>0.80</td>
                <!-- PHP INTEGRATION: echo $ex['production_norm']; -->
                <td>0.45</td>
                <td class="text-center">
                  <!-- PHP INTEGRATION: class="eco-badge score-<?php echo $ex['score_officiel']; ?>" -->
                  <div class="eco-badge score-B" style="width:38px;height:38px;font-size:1rem;">B</div>
                </td>
                <!-- PHP INTEGRATION: echo date('d/m/Y', strtotime($ex['date_ajout'])); -->
                <td><span class="text-muted">12/10/2023</span></td>
                <td>
                  <div class="table-actions">
                    <!-- PHP INTEGRATION: href="formulaire_exemple.php?id_exemple=<?php echo $ex['id_exemple']; ?>&id_produit=<?php echo $id_produit; ?>" -->
                    <a href="formulaire_exemple.php?id_exemple=101&id_produit=1" class="btn btn-sm btn-outline" title="Modifier">
                      <i class="fas fa-pen"></i>
                    </a>
                    <!-- PHP INTEGRATION: action="delete_exemple.php" -->
                    <form action="#" method="POST" style="display:inline;"
                          onsubmit="return confirm('Supprimer cet exemple KNN ?');">
                      <!-- PHP INTEGRATION: values dynamiques -->
                      <input type="hidden" name="id_exemple" value="101">
                      <input type="hidden" name="id_produit" value="1">
                      <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">
                        <i class="fas fa-trash"></i>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>

              <tr class="alt-row">
                <td><strong>#102</strong></td>
                <td>0.30</td>
                <td>0.70</td>
                <td>0.50</td>
                <td class="text-center">
                  <div class="eco-badge score-B" style="width:38px;height:38px;font-size:1rem;">B</div>
                </td>
                <td><span class="text-muted">14/10/2023</span></td>
                <td>
                  <div class="table-actions">
                    <a href="formulaire_exemple.php?id_exemple=102&id_produit=1" class="btn btn-sm btn-outline" title="Modifier">
                      <i class="fas fa-pen"></i>
                    </a>
                    <form action="#" method="POST" style="display:inline;"
                          onsubmit="return confirm('Supprimer cet exemple KNN ?');">
                      <input type="hidden" name="id_exemple" value="102">
                      <input type="hidden" name="id_produit" value="1">
                      <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">
                        <i class="fas fa-trash"></i>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>

              <!-- PHP INTEGRATION: <?php endforeach; ?> -->

            </tbody>
          </table>
        </div>

        <!-- PHP INTEGRATION: <?php endif; ?> -->
      </div>

    </div><!-- /.dashboard-container -->
  </main>

</div><!-- /.app-wrapper -->
</body>
</html>
