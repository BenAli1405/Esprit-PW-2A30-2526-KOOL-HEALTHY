<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Back-office – Formulaire exemple KNN</title>
  <meta name="description" content="Ajouter ou modifier un exemple KNN pour l'éco-score IA – Kool Healthy.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ===== SIDEBAR ===== -->
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>administration · produit &amp; éco-score</p>
    </div>

    <nav class="nav-menu">
      <div class="nav-section-title">Front-office</div>
      <a href="scan.php"     class="nav-item"><i class="fas fa-barcode"></i><span>Scanner un produit</span></a>
      <a href="comparer.php" class="nav-item"><i class="fas fa-code-compare"></i><span>Comparer</span></a>

      <div class="nav-section-title">Administration</div>
      <a href="liste_produits.php"     class="nav-item active"><i class="fas fa-boxes-stacked"></i><span>Produits</span></a>
      <a href="formulaire_produit.php" class="nav-item"><i class="fas fa-plus-circle"></i><span>Ajouter un produit</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
        <div class="user-info">
          <p>Administrateur</p>
          <small>admin@koolhealthy.com</small>
        </div>
      </div>
    </div>
  </aside>

  <!-- ===== MAIN ===== -->
  <main class="main-content">

    <!-- Top bar -->
    <div class="top-bar">
      <div class="page-title">
        <!-- PHP INTEGRATION: conditionner "Ajouter" / "Modifier" -->
        <h1><i class="fas fa-graduation-cap" style="color:var(--bleu-tech);font-size:1.2rem;"></i> Ajouter / Modifier un exemple KNN</h1>
        <p>Données d'entraînement · valeurs normalisées de 0.00 à 1.00</p>
      </div>
      <div class="header-actions">
        <!-- PHP INTEGRATION: href="liste_exemples.php?id_produit=<?php echo $id_produit; ?>" -->
        <a href="liste_exemples.php?id_produit=1" class="btn btn-outline">
          <i class="fas fa-arrow-left"></i> Retour aux exemples
        </a>
      </div>
    </div>

    <div class="dashboard-container">
      <div style="max-width:680px; margin:0 auto;">

        <!-- PHP INTEGRATION: bloc erreurs de validation
        <?php if (!empty($erreurs)): ?>
        <div class="info-box" style="border-left-color:var(--badge-e); background:#FFEBEE; color:#C62828; margin-bottom:20px;">
          <ul style="padding-left:18px; margin-top:6px;">
            <?php foreach ($erreurs as $err): ?><li><?php echo $err; ?></li><?php endforeach; ?>
          </ul>
        </div>
        <?php endif; ?>
        -->

        <!-- Explication métier -->
        <div class="info-box info-green" style="margin-bottom:24px;">
          <i class="fas fa-circle-info"></i>
          <strong>Rappel KNN :</strong> Chaque exemple est un vecteur de critères normalisés associé à un éco-score
          officiel connu. L'algorithme KNN calcule l'éco-score d'un nouveau produit par proximité avec ces exemples.
        </div>

        <div class="card-panel">
          <div class="panel-header">
            <h3><i class="fas fa-sliders"></i> Critères environnementaux</h3>
            <span class="badge-eco">Valeurs 0.00 → 1.00</span>
          </div>

          <!-- PHP INTEGRATION: action="formulaire_exemple.php" method="POST" -->
          <form action="#" method="POST" id="exempleForm">
            <!-- PHP INTEGRATION: valeurs cachées -->
            <!-- <input type="hidden" name="id_produit" value="<?php echo $id_produit; ?>"> -->
            <!-- <input type="hidden" name="id_exemple"  value="<?php echo $exemple['id_exemple'] ?? ''; ?>"> -->
            <input type="hidden" name="id_produit" value="1">

            <!-- Origine -->
            <div class="form-group">
              <label class="form-label" for="origine_norm">
                <i class="fas fa-earth-europe" style="color:var(--bleu-tech);"></i>
                Origine géographique (normalisée) *
              </label>
              <span class="form-hint" style="margin-bottom:8px; display:block;">
                0.00 = production locale excellente · 1.00 = importé très lointain
              </span>
              <!-- PHP INTEGRATION: value="<?php echo $exemple['origine_norm'] ?? ''; ?>" -->
              <input type="number" step="0.01" min="0" max="1"
                     id="origine_norm" name="origine_norm"
                     class="form-control" placeholder="Ex : 0.25" required>
            </div>

            <!-- Emballage -->
            <div class="form-group">
              <label class="form-label" for="emballage_norm">
                <i class="fas fa-box" style="color:var(--bleu-tech);"></i>
                Emballage (normalisé) *
              </label>
              <span class="form-hint" style="margin-bottom:8px; display:block;">
                0.00 = sans emballage / recyclable · 1.00 = plastique non recyclable
              </span>
              <!-- PHP INTEGRATION: value="<?php echo $exemple['emballage_norm'] ?? ''; ?>" -->
              <input type="number" step="0.01" min="0" max="1"
                     id="emballage_norm" name="emballage_norm"
                     class="form-control" placeholder="Ex : 0.80" required>
            </div>

            <!-- Production -->
            <div class="form-group">
              <label class="form-label" for="production_norm">
                <i class="fas fa-industry" style="color:var(--bleu-tech);"></i>
                Mode de production (normalisé) *
              </label>
              <span class="form-hint" style="margin-bottom:8px; display:block;">
                0.00 = agriculture bio / durable · 1.00 = production intensive
              </span>
              <!-- PHP INTEGRATION: value="<?php echo $exemple['production_norm'] ?? ''; ?>" -->
              <input type="number" step="0.01" min="0" max="1"
                     id="production_norm" name="production_norm"
                     class="form-control" placeholder="Ex : 0.45" required>
            </div>

            <!-- Score officiel -->
            <div class="form-group">
              <label class="form-label" for="score_officiel">
                <i class="fas fa-leaf" style="color:var(--vert-kool);"></i>
                Éco-score officiel connu (A–E) *
              </label>
              <!-- PHP INTEGRATION: selected conditionné par $exemple['score_officiel'] -->
              <select id="score_officiel" name="score_officiel" class="form-control" required>
                <option value="">-- Choisir un score --</option>
                <option value="A">A – Excellent impact environnemental</option>
                <option value="B">B – Bon impact</option>
                <option value="C">C – Impact modéré</option>
                <option value="D">D – Mauvais impact</option>
                <option value="E">E – Très mauvais impact</option>
              </select>
            </div>

            <!-- Aperçu badge (JS) -->
            <div style="margin-bottom:24px; display:flex; align-items:center; gap:14px;">
              <span style="font-size:0.82rem; color:var(--gris-texte);">Aperçu du badge :</span>
              <div id="scoreBadgePreview" class="eco-badge" style="width:44px;height:44px;font-size:1.1rem;background:var(--gris-moyen);">?</div>
            </div>

            <div class="form-actions">
              <button type="submit" class="btn btn-primary" id="saveExempleBtn">
                <i class="fas fa-save"></i> Enregistrer l'exemple
              </button>
              <!-- PHP INTEGRATION: href="liste_exemples.php?id_produit=<?php echo $id_produit; ?>" -->
              <a href="liste_exemples.php?id_produit=1" class="btn btn-outline">
                <i class="fas fa-times"></i> Annuler
              </a>
            </div>
          </form>
        </div>

      </div>
    </div><!-- /.dashboard-container -->
  </main>

</div><!-- /.app-wrapper -->

<script>
  /* Aperçu badge éco-score en temps réel */
  const scoreColors = {
    A: '#388E3C', B: '#8BC34A', C: '#F9A825', D: '#E67E22', E: '#D32F2F'
  };

  const selectEl  = document.getElementById('score_officiel');
  const badgeEl   = document.getElementById('scoreBadgePreview');

  selectEl.addEventListener('change', function () {
    const val = this.value;
    badgeEl.textContent    = val || '?';
    badgeEl.style.background = val ? scoreColors[val] : 'var(--gris-moyen)';
    badgeEl.style.color    = val ? 'white' : '#9E9E9E';
  });

  document.getElementById('exempleForm').addEventListener('submit', function () {
    const btn = document.getElementById('saveExempleBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enregistrement…';
    btn.disabled  = true;
  });
</script>
</body>
</html>
