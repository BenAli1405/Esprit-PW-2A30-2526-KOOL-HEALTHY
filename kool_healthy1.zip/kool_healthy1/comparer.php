<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Comparer deux produits</title>
  <meta name="description" content="Comparez l'éco-score de deux produits alimentaires grâce à l'IA KNN de Kool Healthy.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ===== SIDEBAR ===== -->
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>espace nutrition · éco-score IA</p>
    </div>

    <nav class="nav-menu">
      <a href="scan.php"     class="nav-item"><i class="fas fa-barcode"></i><span>Scanner un produit</span></a>
      <a href="comparer.php" class="nav-item active"><i class="fas fa-code-compare"></i><span>Comparer</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user"></i></div>
        <div class="user-info">
          <p>Mon espace</p>
          <small>Produit &amp; Éco-score</small>
        </div>
      </div>
    </div>
  </aside>

  <!-- ===== MAIN ===== -->
  <main class="main-content">

    <!-- Top bar -->
    <div class="top-bar">
      <div class="page-title">
        <h1><i class="fas fa-scale-balanced" style="color:var(--bleu-tech);font-size:1.2rem;"></i> Comparer deux produits</h1>
        <p>Analysez et comparez l'impact environnemental de deux produits côte à côte</p>
      </div>
      <div class="header-actions">
        <a href="scan.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Scanner</a>
      </div>
    </div>

    <div class="dashboard-container">

      <!-- ── Formulaire ── -->
      <div class="card-panel">
        <div class="panel-header">
          <h3><i class="fas fa-magnifying-glass"></i> Choisir les produits</h3>
          <span class="badge-tech">Open Food Facts · IA KNN</span>
        </div>

        <!-- PHP INTEGRATION: action="comparer.php" method="POST" -->
        <form action="comparer.php" method="POST" id="compareForm">
          <div class="compare-grid" style="margin-bottom:20px;">
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label" for="barcode1"><i class="fas fa-1" style="color:var(--vert-kool);"></i> Produit 1</label>
              <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($_POST['barcode1'] ?? ''); ?>" -->
              <input type="text" id="barcode1" name="barcode1" class="form-control"
                     placeholder="Code-barres ou nom du produit" value="123456789" required>
            </div>
            <div class="form-group" style="margin-bottom:0;">
              <label class="form-label" for="barcode2"><i class="fas fa-2" style="color:var(--bleu-tech);"></i> Produit 2</label>
              <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($_POST['barcode2'] ?? ''); ?>" -->
              <input type="text" id="barcode2" name="barcode2" class="form-control"
                     placeholder="Code-barres ou nom du produit" value="987654321" required>
            </div>
          </div>
          <button type="submit" class="btn btn-primary" id="compareBtn">
            <i class="fas fa-code-compare"></i> Lancer la comparaison
          </button>
        </form>
      </div>

      <!-- ── RÉSULTATS ─────────────────────────────────────────────────────────
           PHP INTEGRATION: <?php if (isset($produit1) && isset($produit2)): ?>
      ─────────────────────────────────────────────────────────────────────── -->

      <!-- Info banner -->
      <div class="info-box info-green" style="margin-bottom:24px;">
        <i class="fas fa-check-circle"></i>
        <strong>Comparaison effectuée.</strong> Le meilleur choix est mis en évidence par le score IA le plus élevé.
      </div>

      <div class="compare-grid">

        <!-- Produit 1 (winner) -->
        <!-- PHP INTEGRATION: ajouter class="card-panel winner" si $produit1 meilleur -->
        <div class="card-panel" style="border: 2px solid var(--vert-kool);">
          <div class="panel-header">
            <h3><i class="fas fa-trophy" style="color:var(--vert-kool);"></i> Produit 1</h3>
            <span class="winner-label"><i class="fas fa-star"></i> Meilleur choix</span>
          </div>

          <div class="text-center" style="margin-bottom:20px;">
            <!-- PHP INTEGRATION: echo htmlspecialchars($produit1['nom']); -->
            <h3 style="font-size:1.1rem; margin-bottom:4px;">Pâtes complètes Bio</h3>
            <!-- PHP INTEGRATION: echo $produit1['marque'] . ' · ' . $produit1['categorie']; -->
            <p class="text-muted" style="font-size:0.82rem;">Panzani · Épicerie</p>
            <div style="margin-top:16px;">
              <!-- PHP INTEGRATION: class="eco-badge score-<?php echo $score1; ?>" -->
              <div class="eco-badge score-B">B</div>
            </div>
          </div>

          <ul class="criteria-list">
            <li><span><i class="fas fa-earth-europe"></i> Origine</span><strong>0.20</strong></li>
            <li><span><i class="fas fa-box"></i> Emballage</span><strong>0.80</strong></li>
            <li><span><i class="fas fa-industry"></i> Production</span><strong>0.45</strong></li>
          </ul>

          <div style="margin-top:16px;">
            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px;">
              <span class="text-muted">Score global</span><strong style="color:var(--vert-kool);">75 / 100</strong>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-fill" style="width:75%;"></div>
            </div>
          </div>
        </div>

        <!-- Produit 2 -->
        <div class="card-panel">
          <div class="panel-header">
            <h3><i class="fas fa-box-open" style="color:var(--bleu-tech);"></i> Produit 2</h3>
            <span class="badge-tech">Score IA</span>
          </div>

          <div class="text-center" style="margin-bottom:20px;">
            <!-- PHP INTEGRATION: echo htmlspecialchars($produit2['nom']); -->
            <h3 style="font-size:1.1rem; margin-bottom:4px;">Pâtes standard</h3>
            <!-- PHP INTEGRATION: echo $produit2['marque'] . ' · ' . $produit2['categorie']; -->
            <p class="text-muted" style="font-size:0.82rem;">Barilla · Épicerie</p>
            <div style="margin-top:16px;">
              <!-- PHP INTEGRATION: class="eco-badge score-<?php echo $score2; ?>" -->
              <div class="eco-badge score-D">D</div>
            </div>
          </div>

          <ul class="criteria-list">
            <li><span><i class="fas fa-earth-europe"></i> Origine</span><strong>0.60</strong></li>
            <li><span><i class="fas fa-box"></i> Emballage</span><strong>0.20</strong></li>
            <li><span><i class="fas fa-industry"></i> Production</span><strong>0.80</strong></li>
          </ul>

          <div style="margin-top:16px;">
            <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:4px;">
              <span class="text-muted">Score global</span><strong style="color:var(--badge-d);">42 / 100</strong>
            </div>
            <div class="progress-bar-bg">
              <div class="progress-fill" style="width:42%; background:var(--badge-d);"></div>
            </div>
          </div>
        </div>

      </div><!-- /.compare-grid -->

      <!-- Synthèse IA -->
      <div class="card-panel">
        <div class="panel-header">
          <h3><i class="fas fa-robot"></i> Synthèse IA</h3>
          <span class="badge-eco">Recommandation personnalisée</span>
        </div>
        <p style="font-size:0.9rem;">
          <i class="fas fa-lightbulb" style="color:var(--bleu-tech);"></i>
          <strong>Pâtes complètes Bio</strong> obtient un meilleur éco-score grâce à une origine plus locale.
          L'emballage reste un point d'amélioration. Pour un score A, préférez un emballage carton recyclable.
        </p>
      </div>

      <!-- PHP INTEGRATION: <?php endif; ?> -->

    </div><!-- /.dashboard-container -->
  </main>

</div><!-- /.app-wrapper -->

<script>
  document.getElementById('compareForm').addEventListener('submit', function () {
    const btn = document.getElementById('compareBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Comparaison en cours…';
    btn.disabled = true;
  });
</script>
</body>
</html>
