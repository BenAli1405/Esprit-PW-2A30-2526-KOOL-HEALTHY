<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Back-office – Formulaire produit</title>
  <!-- PHP INTEGRATION: conditionner le titre: "Ajouter" ou "Modifier" -->
  <meta name="description" content="Ajouter ou modifier un produit dans le module Éco-score.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ===== SIDEBAR ===== -->
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>administration · produit &amp; éco-score</p>
    </div>

    <nav class="nav-menu">
      <div class="nav-section-title">Front-office</div>
      <a href="scan.php"     class="nav-item"><i class="fas fa-barcode"></i><span>Scanner un produit</span></a>
      <a href="comparer.php" class="nav-item"><i class="fas fa-code-compare"></i><span>Comparer</span></a>

      <div class="nav-section-title">Administration</div>
      <a href="liste_produits.php"     class="nav-item"><i class="fas fa-boxes-stacked"></i><span>Produits</span></a>
      <a href="formulaire_produit.php" class="nav-item active"><i class="fas fa-plus-circle"></i><span>Ajouter un produit</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
        <div class="user-info">
          <p>Administrateur</p>
          <small>admin@koolhealthy.com</small>
        </div>
      </div>
    </div>
  </aside>

  <!-- ===== MAIN ===== -->
  <main class="main-content">

    <!-- Top bar -->
    <div class="top-bar">
      <div class="page-title">
        <!-- PHP INTEGRATION: conditionner le titre "Ajouter" / "Modifier" -->
        <h1><i class="fas fa-box-open" style="color:var(--bleu-tech);font-size:1.2rem;"></i> Ajouter / Modifier un produit</h1>
        <p>Remplissez les informations du produit · les champs marqués * sont obligatoires</p>
      </div>
      <div class="header-actions">
        <a href="liste_produits.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Retour à la liste</a>
      </div>
    </div>

    <div class="dashboard-container">
      <div style="max-width:680px; margin:0 auto;">

        <!-- PHP INTEGRATION: bloc erreurs de validation
        <?php if (!empty($erreurs)): ?>
        <div class="info-box" style="border-left-color:var(--badge-e); background:#FFEBEE; color:#C62828; margin-bottom:20px;">
          <ul style="padding-left:18px; margin-top:6px;">
            <?php foreach ($erreurs as $err): ?><li><?php echo $err; ?></li><?php endforeach; ?>
          </ul>
        </div>
        <?php endif; ?>
        -->

        <!-- PHP INTEGRATION: message de succès
        <?php if (isset($success)): ?>
        <div class="info-box info-green" style="margin-bottom:20px;">
          <i class="fas fa-check-circle"></i> <?php echo $success; ?>
        </div>
        <?php endif; ?>
        -->

        <div class="card-panel">
          <div class="panel-header">
            <h3><i class="fas fa-box-open"></i> Informations produit</h3>
            <span class="badge-tech">Catalogue</span>
          </div>

          <!-- PHP INTEGRATION: action="formulaire_produit.php" method="POST" -->
          <form action="#" method="POST" id="productForm">
            <!-- PHP INTEGRATION: si modification, ajouter input hidden id_produit -->
            <!-- <input type="hidden" name="id_produit" value="<?php echo $produit['id_produit'] ?? ''; ?>"> -->

            <div class="form-group">
              <label class="form-label" for="nom">Nom du produit *</label>
              <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($donnees['nom'] ?? ''); ?>" -->
              <input type="text" id="nom" name="nom" class="form-control"
                     placeholder="Ex : Pâtes complètes Bio" required>
            </div>

            <div class="form-group">
              <label class="form-label" for="code_barre">Code-barres</label>
              <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($donnees['code_barre'] ?? ''); ?>" -->
              <input type="text" id="code_barre" name="code_barre" class="form-control"
                     placeholder="13 chiffres EAN-13 · ex : 3017620422003">
              <span class="form-hint">Laissez vide si inconnu – la recherche par nom sera utilisée.</span>
            </div>

            <div class="compare-grid" style="gap:16px;">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label" for="categorie">Catégorie</label>
                <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($donnees['categorie'] ?? ''); ?>" -->
                <input type="text" id="categorie" name="categorie" class="form-control"
                       placeholder="Ex : Épicerie, Boissons…">
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label" for="marque">Marque</label>
                <!-- PHP INTEGRATION: value="<?php echo htmlspecialchars($donnees['marque'] ?? ''); ?>" -->
                <input type="text" id="marque" name="marque" class="form-control"
                       placeholder="Ex : Panzani, Barilla…">
              </div>
            </div>

            <div class="form-actions">
              <button type="submit" class="btn btn-primary" id="saveProductBtn">
                <i class="fas fa-save"></i> Enregistrer le produit
              </button>
              <a href="liste_produits.php" class="btn btn-outline">
                <i class="fas fa-times"></i> Annuler
              </a>
            </div>
          </form>
        </div>

        <!-- Info box KNN -->
        <div class="info-box">
          <i class="fas fa-brain"></i>
          <strong>Étape suivante :</strong> après avoir enregistré le produit, ajoutez des exemples KNN
          pour alimenter l'algorithme d'éco-score IA.
          <a href="liste_exemples.php?id_produit=1" style="color:var(--bleu-tech-dark); margin-left:6px; font-weight:600;">
            Gérer les exemples →
          </a>
        </div>

      </div>
    </div><!-- /.dashboard-container -->
  </main>

</div><!-- /.app-wrapper -->

<script>
  document.getElementById('productForm').addEventListener('submit', function () {
    const btn = document.getElementById('saveProductBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enregistrement…';
    btn.disabled = true;
  });
</script>
</body>
</html>
