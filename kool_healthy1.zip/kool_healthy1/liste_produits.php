<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
  <title>Kool Healthy | Back-office – Gestion des produits</title>
  <meta name="description" content="Administration des produits du module Produit & Éco-score – Kool Healthy.">
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="app-wrapper">

  <!-- ===== SIDEBAR (Tback style) ===== -->
  <aside class="sidebar">
    <div class="logo-area">
      <h2><i class="fas fa-seedling"></i><span>Kool<br>Healthy</span></h2>
      <p>administration · produit &amp; éco-score</p>
    </div>

    <nav class="nav-menu">
      <div class="nav-section-title">Front-office</div>
      <a href="scan.php"     class="nav-item"><i class="fas fa-barcode"></i><span>Scanner un produit</span></a>
      <a href="comparer.php" class="nav-item"><i class="fas fa-code-compare"></i><span>Comparer</span></a>

      <div class="nav-section-title">Administration</div>
      <a href="liste_produits.php"  class="nav-item active"><i class="fas fa-boxes-stacked"></i><span>Produits</span></a>
      <a href="formulaire_produit.php" class="nav-item"><i class="fas fa-plus-circle"></i><span>Ajouter un produit</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-badge">
        <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
        <div class="user-info">
          <p>Administrateur</p>
          <small>admin@koolhealthy.com</small>
        </div>
      </div>
    </div>
  </aside>

  <!-- ===== MAIN ===== -->
  <main class="main-content">

    <!-- Top bar -->
    <div class="top-bar">
      <div class="page-title">
        <h1><i class="fas fa-boxes-stacked" style="color:var(--bleu-tech);font-size:1.2rem;"></i> Liste des produits</h1>
        <p>Gestion back-office · créer, modifier, gérer les données KNN</p>
      </div>
      <div class="header-actions">
        <a href="scan.php"              class="btn btn-outline"><i class="fas fa-eye"></i> Voir le site</a>
        <a href="formulaire_produit.php" class="btn btn-primary"><i class="fas fa-plus"></i> Ajouter un produit</a>
      </div>
    </div>

    <div class="dashboard-container">

      <!-- Stats rapides -->
      <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(180px,1fr)); margin-bottom:28px;">
        <div class="stat-card">
          <div class="stat-title">Total produits</div>
          <!-- PHP INTEGRATION: echo count($produits); -->
          <div class="stat-value">2</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Exemples KNN</div>
          <!-- PHP INTEGRATION: echo $total_exemples; -->
          <div class="stat-value">4</div>
        </div>
        <div class="stat-card">
          <div class="stat-title">Scores calculés</div>
          <div class="stat-value">2</div>
        </div>
      </div>

      <!-- Tableau des produits -->
      <div class="card-panel">
        <div class="panel-header">
          <h3><i class="fas fa-list"></i> Catalogue produits</h3>
          <span class="badge-tech">CRUD · KNN</span>
        </div>

        <!-- PHP INTEGRATION: message si aucun produit
        <?php if (empty($produits)): ?>
        <div class="info-box" style="text-align:center;">
          <i class="fas fa-inbox"></i> Aucun produit enregistré.
          <a href="formulaire_produit.php" style="color:var(--bleu-tech); margin-left:8px;">Ajouter le premier →</a>
        </div>
        <?php else: ?>
        -->

        <div style="overflow-x:auto;">
          <table class="data-table" id="productsTable">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nom du produit</th>
                <th>Code-barres</th>
                <th>Catégorie</th>
                <th>Marque</th>
                <th style="min-width:200px;">Actions</th>
              </tr>
            </thead>
            <tbody>

              <!-- PHP INTEGRATION: <?php foreach ($produits as $produit): ?> -->

              <tr>
                <!-- PHP INTEGRATION: echo $produit['id_produit']; -->
                <td><strong>#1</strong></td>
                <!-- PHP INTEGRATION: echo htmlspecialchars($produit['nom']); -->
                <td>Pâtes complètes Bio</td>
                <!-- PHP INTEGRATION: echo htmlspecialchars($produit['code_barre']); -->
                <td><code style="font-size:0.8rem; color:var(--gris-texte);">1234567890123</code></td>
                <!-- PHP INTEGRATION: echo htmlspecialchars($produit['categorie']); -->
                <td><span class="status-active">Épicerie</span></td>
                <!-- PHP INTEGRATION: echo htmlspecialchars($produit['marque']); -->
                <td>Panzani</td>
                <td>
                  <div class="table-actions">
                    <!-- PHP INTEGRATION: href="formulaire_produit.php?id=<?php echo $produit['id_produit']; ?>" -->
                    <a href="formulaire_produit.php?id=1" class="btn btn-sm btn-outline" title="Modifier">
                      <i class="fas fa-pen"></i> Modifier
                    </a>
                    <!-- PHP INTEGRATION: href="liste_exemples.php?id_produit=<?php echo $produit['id_produit']; ?>" -->
                    <a href="liste_exemples.php?id_produit=1" class="btn btn-sm btn-outline" title="Gérer KNN" style="border-color:var(--vert-kool);color:var(--vert-kool);">
                      <i class="fas fa-brain"></i> KNN
                    </a>
                    <!-- PHP INTEGRATION: action="delete_produit.php" -->
                    <form action="#" method="POST" style="display:inline;"
                          onsubmit="return confirm('Supprimer ce produit et tous ses exemples KNN ?');">
                      <!-- PHP INTEGRATION: value="<?php echo $produit['id_produit']; ?>" -->
                      <input type="hidden" name="id_produit" value="1">
                      <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">
                        <i class="fas fa-trash"></i>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>

              <tr class="alt-row">
                <td><strong>#2</strong></td>
                <td>Jus d'orange</td>
                <td><code style="font-size:0.8rem; color:var(--gris-texte);">9876543210987</code></td>
                <td><span class="status-active">Boissons</span></td>
                <td>Tropicana</td>
                <td>
                  <div class="table-actions">
                    <a href="formulaire_produit.php?id=2" class="btn btn-sm btn-outline" title="Modifier">
                      <i class="fas fa-pen"></i> Modifier
                    </a>
                    <a href="liste_exemples.php?id_produit=2" class="btn btn-sm btn-outline" title="Gérer KNN" style="border-color:var(--vert-kool);color:var(--vert-kool);">
                      <i class="fas fa-brain"></i> KNN
                    </a>
                    <form action="#" method="POST" style="display:inline;"
                          onsubmit="return confirm('Supprimer ce produit et tous ses exemples KNN ?');">
                      <input type="hidden" name="id_produit" value="2">
                      <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">
                        <i class="fas fa-trash"></i>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>

              <!-- PHP INTEGRATION: <?php endforeach; ?> -->

            </tbody>
          </table>
        </div>

        <!-- PHP INTEGRATION: <?php endif; ?> -->
      </div>

    </div><!-- /.dashboard-container -->
  </main>

</div><!-- /.app-wrapper -->
</body>
</html>
