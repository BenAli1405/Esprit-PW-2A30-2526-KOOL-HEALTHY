<?php
/**
 * ⚠️ FICHIER D'EXEMPLE / DÉMONSTRATION ⚠️
 * Ceci montre comment lier le code HTML/CSS généré avec un back-end PHP/PDO.
 * Ce script n'est pas censé être exécuté tel quel, mais sert de guide d'intégration.
 */

// 1. Initialisation de la BDD
// ==========================================
/*
try {
    $pdo = new PDO("mysql:host=localhost;dbname=kool_healthy;charset=utf8mb4", "root", "", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}
*/

// ==========================================
// 2. Exemple de Traitement (scan.php)
// ==========================================
$erreurs = [];
$produit = null;
$score_calcule = null;
$nb_exemples = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['barcode'])) {
    // Nettoyage de la saisie
    $barcode = filter_var(trim($_POST['barcode']), FILTER_SANITIZE_STRING);

    if (empty($barcode)) {
        $erreurs[] = "Le code-barres ne peut pas être vide.";
    } else {
        // Requête préparée pour trouver le produit
        /*
        $stmt = $pdo->prepare("SELECT * FROM Produit WHERE code_barre = :code OR nom LIKE :nom LIMIT 1");
        $stmt->execute([
            'code' => $barcode,
            'nom' => "%$barcode%"
        ]);
        $produit = $stmt->fetch();
        */

        // Données mockées pour la démo
        $produit = [
            'id_produit' => 1,
            'nom' => 'Pâtes complètes Bio',
            'marque' => 'Panzani',
            'categorie' => 'Épicerie',
            'code_barre' => '1234567890123'
        ];

        if ($produit) {
            // Récupérer les moyennes des critères normalisés via les exemples pour afficher sur la page
            /*
            $stmtEx = $pdo->prepare("SELECT 
                 COUNT(id_exemple) as nb_exemples, 
                 AVG(origine_norm) as avg_origine, 
                 AVG(emballage_norm) as avg_emballage, 
                 AVG(production_norm) as avg_prod 
                 FROM ExempleKNN WHERE id_produit = :id");
            $stmtEx->execute(['id' => $produit['id_produit']]);
            $stats_knn = $stmtEx->fetch();
            $nb_exemples = $stats_knn['nb_exemples'];
            */

            $stats_knn = ['avg_origine' => 0.20, 'avg_emballage' => 0.80, 'avg_prod' => 0.45];
            $nb_exemples = 15;

            // Appel théorique à l'algorithme K-Nearest Neighbors
            // $score_calcule = algorithme_knn($stats_knn['avg_origine'], $stats_knn['avg_emballage'], $stats_knn['avg_prod'], $k=3, $pdo);
            $score_calcule = 'B'; 
        } else {
            $erreurs[] = "Produit introuvable dans notre base.";
        }
    }
}

// ==========================================
// 3. Exemple de Validation (formulaire_produit.php)
// ==========================================
/*
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nom'])) {
    $nom = trim($_POST['nom']);
    $code_barre = trim($_POST['code_barre']);
    
    // Validation PHP pure (indépendante de HTML5 required)
    if (empty($nom)) {
        $erreurs[] = "Le nom du produit est strictement obligatoire.";
    }
    
    if (strlen($code_barre) > 0 && !preg_match('/^[0-9]+$/', $code_barre)) {
        $erreurs[] = "Le code-barres doit contenir uniquement des chiffres.";
    }

    if (empty($erreurs)) {
        // Enregistrement en base
        // $stmt = $pdo->prepare("INSERT INTO Produit (nom, code_barre, categorie, marque) VALUES (?, ?, ?, ?)");
        // $stmt->execute([$nom, $code_barre, $_POST['categorie'], $_POST['marque']]);
        
        // Redirection
        // header("Location: liste_produits.php");
        // exit;
    }
}
*/

?>

<!-- Le reste du fichier scan.php ou autre se trouverait ici en dessous, en réutilisant 
     les variables $produit, $score_calcule, $erreurs... -->
